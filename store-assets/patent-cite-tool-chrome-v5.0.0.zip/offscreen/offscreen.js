// src/offscreen/pdf-parser.js
import { getDocument, GlobalWorkerOptions } from "../lib/pdf.mjs";
GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("lib/pdf.worker.mjs");
async function hasTextLayer(pdf) {
  const pagesToCheck = Math.min(pdf.numPages, 5);
  let totalItems = 0;
  for (let i = 1; i <= pagesToCheck; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const nonEmpty = textContent.items.filter(
      (item) => item.str && item.str.trim().length > 0
    );
    totalItems += nonEmpty.length;
  }
  return totalItems >= 5;
}
async function extractTextFromPdf(pdfData) {
  const pdf = await getDocument({ data: pdfData, useSystemFonts: true }).promise;
  const hasText = await hasTextLayer(pdf);
  if (!hasText) {
    pdf.destroy();
    throw new Error("NO_TEXT_LAYER");
  }
  const results = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const viewport = page.getViewport({ scale: 1 });
    const pageItems = textContent.items.filter((item) => item.str && item.str.trim().length > 0).map((item) => ({
      text: item.str,
      x: item.transform[4],
      y: item.transform[5],
      width: item.width,
      height: item.height,
      fontName: item.fontName,
      hasEOL: item.hasEOL,
      pageNum: i,
      pageWidth: viewport.width,
      pageHeight: viewport.height
    }));
    results.push({
      pageNum: i,
      items: pageItems,
      pageWidth: viewport.width,
      pageHeight: viewport.height
    });
  }
  pdf.destroy();
  return results;
}

// src/offscreen/position-map-builder.js
function isTwoColumnPage(pageItems, pageWidth) {
  if (pageItems.length < 20) return false;
  const midX = pageWidth / 2;
  let leftCount = 0;
  let rightCount = 0;
  for (const item of pageItems) {
    if (item.x < midX) leftCount++;
    else rightCount++;
  }
  const total = leftCount + rightCount;
  if (total < 30) return false;
  const ratio = Math.min(leftCount, rightCount) / Math.max(leftCount, rightCount);
  return ratio > 0.3;
}
function findColumnBoundary(pageItems, pageWidth) {
  const buckets = new Array(Math.ceil(pageWidth)).fill(0);
  for (const item of pageItems) {
    const bucketIdx = Math.floor(item.x);
    if (bucketIdx >= 0 && bucketIdx < buckets.length) {
      buckets[bucketIdx]++;
    }
  }
  const searchStart = Math.floor(pageWidth * 0.25);
  const searchEnd = Math.ceil(pageWidth * 0.75);
  const pageMid = pageWidth / 2;
  const gaps = [];
  let currentGapStart = -1;
  for (let i = searchStart; i < searchEnd; i++) {
    if (buckets[i] === 0) {
      if (currentGapStart === -1) currentGapStart = i;
    } else {
      if (currentGapStart !== -1) {
        const width = i - currentGapStart;
        if (width >= 5) gaps.push({ start: currentGapStart, end: i, width });
        currentGapStart = -1;
      }
    }
  }
  if (currentGapStart !== -1) {
    const width = searchEnd - currentGapStart;
    if (width >= 5) gaps.push({ start: currentGapStart, end: searchEnd, width });
  }
  if (gaps.length === 0) return pageMid;
  let bestGap = gaps[0];
  let bestDist = Math.abs((gaps[0].start + gaps[0].end) / 2 - pageMid);
  for (let i = 1; i < gaps.length; i++) {
    const gapMid = (gaps[i].start + gaps[i].end) / 2;
    const dist = Math.abs(gapMid - pageMid);
    if (dist < bestDist) {
      bestDist = dist;
      bestGap = gaps[i];
    }
  }
  return (bestGap.start + bestGap.end) / 2;
}
function extractPrintedColumnNumbers(items, pageHeight, pageWidth) {
  const headerThreshold = pageHeight - 90;
  const midX = pageWidth / 2;
  const headerNumbers = [];
  for (const item of items) {
    if (item.y >= headerThreshold) {
      const text = item.text.trim();
      if (/^\d{1,3}$/.test(text)) {
        headerNumbers.push({ value: parseInt(text, 10), x: item.x });
      }
    }
  }
  if (headerNumbers.length === 0) return null;
  const leftNums = headerNumbers.filter((n) => n.x < midX).sort((a, b) => a.x - b.x);
  const rightNums = headerNumbers.filter((n) => n.x >= midX).sort((a, b) => a.x - b.x);
  let left, right;
  if (leftNums.length > 0 && rightNums.length > 0) {
    left = leftNums[0].value;
    right = rightNums[0].value;
  } else if (rightNums.length > 0 && leftNums.length === 0) {
    right = rightNums[0].value;
    left = right - 1;
  } else if (leftNums.length > 0 && rightNums.length === 0) {
    left = leftNums[0].value;
    right = left + 1;
  } else {
    return null;
  }
  if (right !== left + 1) return null;
  if (left < 1 || left % 2 !== 1) return null;
  return { left, right };
}
function filterGutterLineNumbers(items, boundary, pageWidth) {
  const pageMid = pageWidth / 2;
  return items.filter((item) => {
    const text = item.text.trim();
    if (!/^\d{1,2}$/.test(text)) return true;
    const num = parseInt(text, 10);
    if (num < 5 || num > 65 || num % 5 !== 0) return true;
    const nearBoundary = Math.abs(item.x - boundary) <= 40;
    const nearCenter = Math.abs(item.x - pageMid) <= 40;
    if (!nearBoundary && !nearCenter) return true;
    return false;
  });
}
function stripCrossBoundaryText(items, boundary) {
  return items.map((item) => {
    const itemEnd = item.x + item.width;
    if (itemEnd <= boundary + 20) return item;
    const stripped = item.text.replace(/\s+\b(5|10|15|20|25|30|35|40|45|50|55|60|65)\b\s+.*$/, "");
    if (stripped !== item.text) {
      return { ...item, text: stripped, width: stripped.length / item.text.length * item.width };
    }
    return item;
  });
}
function filterHeadersFooters(items, pageHeight) {
  const headerThreshold = pageHeight - 90;
  const footerThreshold = 40;
  return items.filter((item) => {
    return item.y > footerThreshold && item.y < headerThreshold;
  });
}
function clusterIntoLines(items, yTolerance = 3) {
  if (items.length === 0) return [];
  const sorted = [...items].sort((a, b) => b.y - a.y);
  const lines = [];
  let currentLine = [sorted[0]];
  let currentY = sorted[0].y;
  for (let i = 1; i < sorted.length; i++) {
    if (Math.abs(sorted[i].y - currentY) <= yTolerance) {
      currentLine.push(sorted[i]);
    } else {
      currentLine.sort((a, b) => a.x - b.x);
      lines.push(currentLine);
      currentLine = [sorted[i]];
      currentY = sorted[i].y;
    }
  }
  currentLine.sort((a, b) => a.x - b.x);
  lines.push(currentLine);
  return lines;
}
function buildLineEntry(lineItems, pageNum, column, lineNumber) {
  let text = "";
  for (let i = 0; i < lineItems.length; i++) {
    if (i > 0) {
      const prevEnd = lineItems[i - 1].x + lineItems[i - 1].width;
      const gap = lineItems[i].x - prevEnd;
      if (gap > 1 && !text.endsWith(" ")) {
        text += " ";
      }
    }
    text += lineItems[i].text;
  }
  const firstItem = lineItems[0];
  const lastItem = lineItems[lineItems.length - 1];
  return {
    page: pageNum,
    column,
    lineNumber,
    text,
    hasWrapHyphen: false,
    // Set in post-processing by detectWrapHyphens
    x: firstItem.x,
    y: firstItem.y,
    width: lastItem.x + lastItem.width - firstItem.x,
    height: Math.max(...lineItems.map((item) => item.height)),
    section: "description"
    // Default; updated by detectClaimsBoundary
  };
}
function detectClaimsBoundary(entries) {
  const claimsMarkers = [
    /what\s+is\s+claimed\s+is/i,
    /we\s+claim/i,
    /i\s+claim/i,
    /the\s+invention\s+claimed\s+is/i
  ];
  for (let i = 0; i < entries.length; i++) {
    for (const marker of claimsMarkers) {
      if (marker.test(entries[i].text)) {
        return i;
      }
    }
  }
  return -1;
}
function detectWrapHyphens(entries) {
  for (let i = 0; i < entries.length - 1; i++) {
    const current = entries[i];
    const next = entries[i + 1];
    if (current.column !== next.column) continue;
    if (current.text.endsWith("-")) {
      const nextFirstChar = next.text.trimStart().charAt(0);
      if (nextFirstChar && nextFirstChar === nextFirstChar.toLowerCase() && nextFirstChar !== nextFirstChar.toUpperCase()) {
        current.hasWrapHyphen = true;
      }
    }
  }
}
function extractGutterLineGrid(items, boundary, pageWidth) {
  const pageMid = pageWidth / 2;
  const markers = [];
  for (const item of items) {
    const text = item.text.trim();
    if (!/^\d{1,2}$/.test(text)) continue;
    const num = parseInt(text, 10);
    if (num < 5 || num > 65 || num % 5 !== 0) continue;
    const nearBoundary = Math.abs(item.x - boundary) <= 40;
    const nearCenter = Math.abs(item.x - pageMid) <= 40;
    if (!nearBoundary && !nearCenter) continue;
    markers.push({ lineNumber: num, y: item.y });
  }
  if (markers.length < 2) return null;
  const seen = /* @__PURE__ */ new Map();
  for (const m of markers) {
    if (!seen.has(m.lineNumber)) {
      seen.set(m.lineNumber, m);
    }
  }
  const unique = [...seen.values()];
  if (unique.length < 2) return null;
  unique.sort((a, b) => a.lineNumber - b.lineNumber);
  const perLineSpacings = [];
  for (let i = 1; i < unique.length; i++) {
    const lineDiff = unique[i].lineNumber - unique[i - 1].lineNumber;
    const yDiff = unique[i - 1].y - unique[i].y;
    if (lineDiff > 0 && yDiff > 0) {
      perLineSpacings.push(yDiff / lineDiff);
    }
  }
  if (perLineSpacings.length === 0) return null;
  perLineSpacings.sort((a, b) => a - b);
  const lineSpacing = perLineSpacings[Math.floor(perLineSpacings.length / 2)];
  const firstMarker = unique[0];
  const firstLineY = firstMarker.y + (firstMarker.lineNumber - 1) * lineSpacing;
  return { firstLineY, lineSpacing };
}
function assignLineNumbersByGrid(lines, entries, pageNum, column, grid) {
  for (const lineItems of lines) {
    const avgY = lineItems.reduce((sum, item) => sum + item.y, 0) / lineItems.length;
    const lineNumber = 1 + Math.round((grid.firstLineY - avgY) / grid.lineSpacing);
    entries.push(buildLineEntry(lineItems, pageNum, column, Math.max(1, lineNumber)));
  }
}
function assignLineNumbers(lines, entries, pageNum, column) {
  if (lines.length === 0) return;
  const lineYs = lines.map((lineItems) => {
    const sum = lineItems.reduce((s, item) => s + item.y, 0);
    return sum / lineItems.length;
  });
  const spacings = [];
  for (let i = 1; i < lineYs.length; i++) {
    const spacing = lineYs[i - 1] - lineYs[i];
    if (spacing > 0) spacings.push(spacing);
  }
  if (spacings.length === 0) {
    for (let i = 0; i < lines.length; i++) {
      entries.push(buildLineEntry(lines[i], pageNum, column, i + 1));
    }
    return;
  }
  spacings.sort((a, b) => a - b);
  const medianSpacing = spacings[Math.floor(spacings.length / 2)];
  let lineNumber = 1;
  entries.push(buildLineEntry(lines[0], pageNum, column, lineNumber));
  for (let i = 1; i < lines.length; i++) {
    const gap = lineYs[i - 1] - lineYs[i];
    const lineSpans = Math.max(1, Math.round(gap / medianSpacing));
    lineNumber += lineSpans;
    entries.push(buildLineEntry(lines[i], pageNum, column, lineNumber));
  }
}
function isLikelySpecPage(items, pageHeight) {
  const headerThreshold = pageHeight - 90;
  const headerText = items.filter((it) => it.y >= headerThreshold).map((it) => it.text).join(" ");
  if (headerText.includes("United States Patent")) return false;
  if (/Sheet\s+\d+\s+of\s+\d+/i.test(headerText)) return false;
  if (/\bPage\s+\d+\b/i.test(headerText)) return false;
  const bodyItems = items.filter((it) => it.y > 40 && it.y < headerThreshold);
  if (bodyItems.length < 80) return false;
  return true;
}
function processPageColumns(pageResult, colNums, entries) {
  const { pageNum, items, pageWidth, pageHeight } = pageResult;
  const boundary = findColumnBoundary(items, pageWidth);
  const filtered = filterHeadersFooters(items, pageHeight);
  if (filtered.length === 0) return;
  const grid = extractGutterLineGrid(filtered, boundary, pageWidth);
  const leftItems = filterGutterLineNumbers(
    stripCrossBoundaryText(
      filtered.filter((item) => item.x < boundary),
      boundary
    ),
    boundary,
    pageWidth
  );
  const rightItems = filterGutterLineNumbers(
    filtered.filter((item) => item.x >= boundary),
    boundary,
    pageWidth
  );
  const leftLines = clusterIntoLines(leftItems);
  if (grid) {
    assignLineNumbersByGrid(leftLines, entries, pageNum, colNums.left, grid);
  } else {
    assignLineNumbers(leftLines, entries, pageNum, colNums.left);
  }
  const rightLines = clusterIntoLines(rightItems);
  if (grid) {
    assignLineNumbersByGrid(rightLines, entries, pageNum, colNums.right, grid);
  } else {
    assignLineNumbers(rightLines, entries, pageNum, colNums.right);
  }
}
function buildPositionMap(pageResults) {
  const entries = [];
  const MAX_PAGE_GAP = 20;
  let expectedLeftCol = 1;
  for (const pageResult of pageResults) {
    const { items, pageWidth, pageHeight } = pageResult;
    if (!isTwoColumnPage(items, pageWidth)) continue;
    const colNums = extractPrintedColumnNumbers(items, pageHeight, pageWidth);
    if (!colNums) continue;
    if (colNums.left < expectedLeftCol) continue;
    if (colNums.left - expectedLeftCol > MAX_PAGE_GAP) continue;
    expectedLeftCol = colNums.right + 1;
    processPageColumns(pageResult, colNums, entries);
  }
  if (entries.length === 0) {
    let inferredLeft = 1;
    for (const pageResult of pageResults) {
      const { items, pageWidth, pageHeight } = pageResult;
      if (!isTwoColumnPage(items, pageWidth)) continue;
      if (!isLikelySpecPage(items, pageHeight)) continue;
      const colNums = { left: inferredLeft, right: inferredLeft + 1 };
      inferredLeft += 2;
      processPageColumns(pageResult, colNums, entries);
    }
  }
  const claimsStart = detectClaimsBoundary(entries);
  if (claimsStart >= 0) {
    for (let i = claimsStart; i < entries.length; i++) {
      entries[i].section = "claims";
    }
  }
  detectWrapHyphens(entries);
  return entries;
}

// src/shared/constants.js
var MSG = {
  PATENT_PAGE_DETECTED: "patent-page-detected",
  PDF_LINK_FOUND: "pdf-link-found",
  PDF_LINK_NOT_FOUND: "pdf-link-not-found",
  FETCH_PDF: "fetch-pdf",
  PDF_FETCH_RESULT: "pdf-fetch-result",
  PARSE_PDF: "parse-pdf",
  PARSE_RESULT: "parse-result",
  GET_STATUS: "get-status",
  LOOKUP_POSITION: "lookup-position",
  CITATION_RESULT: "citation-result",
  GENERATE_CITATION: "generate-citation",
  FETCH_USPTO_PDF: "fetch-uspto-pdf",
  USPTO_FETCH_RESULT: "uspto-fetch-result",
  CHECK_CACHE: "check-cache",
  CACHE_HIT_RESULT: "cache-hit-result",
  CACHE_MISS: "cache-miss",
  UPLOAD_TO_CACHE: "upload-to-cache",
  SUBMIT_REPORT: "submit-report"
  // PAY-05
};
var REPORT_CATEGORIES = Object.freeze([
  "inaccurate_citation",
  "no_match",
  "tool_not_working",
  "other"
]);

// src/shared/matching.js
function normalizeText(text) {
  return text.normalize("NFC").replace(/[\u200B\u200C\u200D\uFEFF\u00AD\u200E\u200F\u2060\u2061\u2062\u2063\u2064]/g, "").replace(/[\u2018\u2019\u201A\u201B]/g, "'").replace(/[\u201C\u201D\u201E\u201F]/g, '"').replace(/[\u2013\u2014\u2015]/g, "-").replace(/\uFB01/g, "fi").replace(/\uFB02/g, "fl").replace(/\uFB00/g, "ff").replace(/\uFB03/g, "ffi").replace(/\uFB04/g, "ffl").replace(/\s+/g, " ").trim();
}
var OCR_PAIRS = [
  ["rn", "m"],
  ["cl", "d"],
  ["cI", "d"],
  ["vv", "w"],
  ["li", "h"]
];
function normalizeOcr(text) {
  let result = text;
  for (const [from, to] of OCR_PAIRS) {
    result = result.split(from).join(to);
  }
  return { text: result, changed: result !== text };
}
function buildConcat(positionMap) {
  let concat = "";
  const boundaries = [];
  const changedRanges = [];
  for (let i = 0; i < positionMap.length; i++) {
    const entry = positionMap[i];
    let lineText = normalizeText(entry.text);
    const prev = positionMap[i - 1];
    const prevIsWrapHyphen = prev && prev.column === entry.column && /^[a-z]/.test(lineText) && (prev.hasWrapHyphen || concat.endsWith("-") || /[-\u00AD\u2010\u2011\u2012]\s*$/.test(prev.text));
    if (prevIsWrapHyphen) {
      concat = concat.replace(/-$/, "");
    } else if (concat.length > 0) {
      concat += " ";
    }
    const { text: ocrText, changed } = normalizeOcr(lineText);
    lineText = ocrText;
    const charStart = concat.length;
    concat += lineText;
    boundaries.push({ charStart, charEnd: concat.length, entryIdx: i });
    if (changed) {
      changedRanges.push({ start: charStart, end: concat.length });
    }
  }
  return { concat, boundaries, changedRanges };
}
function findAllOccurrences(haystack, needle) {
  const positions = [];
  let idx = haystack.indexOf(needle);
  while (idx !== -1) {
    positions.push(idx);
    idx = haystack.indexOf(needle, idx + 1);
  }
  return positions;
}
function pickBestByContext(positions, matchLen, concat, contextBefore, contextAfter) {
  if (positions.length === 1) return positions[0];
  if (!contextBefore && !contextAfter) return positions[positions.length - 1];
  const normBefore = contextBefore ? normalizeText(contextBefore) : "";
  const normAfter = contextAfter ? normalizeText(contextAfter) : "";
  const toWords = (s) => s.toLowerCase().split(/\s+/).filter((w) => w.length > 0);
  const beforeWords = toWords(normBefore);
  const afterWords = toWords(normAfter);
  let bestPos = positions[0];
  let bestScore = -1;
  for (const pos of positions) {
    let score = 0;
    if (beforeWords.length > 0) {
      const before = concat.substring(Math.max(0, pos - normBefore.length - 50), pos);
      const concatWords = toWords(before);
      const minLen = Math.min(concatWords.length, beforeWords.length);
      for (let i = 1; i <= minLen; i++) {
        if (concatWords[concatWords.length - i] === beforeWords[beforeWords.length - i]) score++;
      }
    }
    if (afterWords.length > 0) {
      const after = concat.substring(pos + matchLen, pos + matchLen + normAfter.length + 50);
      const concatWords = toWords(after);
      const minLen = Math.min(concatWords.length, afterWords.length);
      for (let i = 0; i < minLen; i++) {
        if (concatWords[i] === afterWords[i]) score++;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestPos = pos;
    }
  }
  return bestPos;
}
function whitespaceStrippedMatch(normalized, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < 2) return null;
  const concatStripped = [];
  const strippedToOriginal = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStripped.push(concat[i]);
    }
  }
  const concatStrippedStr = concatStripped.join("");
  let allIdx = findAllOccurrences(concatStrippedStr, selStripped);
  let confidence = 0.99;
  if (allIdx.length === 0) {
    allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), selStripped.toLowerCase());
    confidence = 0.98;
  }
  if (allIdx.length === 0) {
    const trimmed = selStripped.replace(/^[.,;:!?]+/, "").replace(/[.,;:!?]+$/, "");
    if (trimmed.length >= 2 && trimmed !== selStripped) {
      allIdx = findAllOccurrences(concatStrippedStr, trimmed);
      confidence = 0.98;
      if (allIdx.length === 0) {
        allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), trimmed.toLowerCase());
        confidence = 0.97;
      }
    }
  }
  let idx = -1;
  if (allIdx.length > 0) {
    if (allIdx.length === 1) {
      idx = allIdx[0];
    } else {
      const origPositions = allIdx.map((si) => strippedToOriginal[si]);
      const origLen = strippedToOriginal[allIdx[0] + selStripped.length - 1] + 1 - strippedToOriginal[allIdx[0]];
      const bestOrig = pickBestByContext(origPositions, origLen, concat, contextBefore, contextAfter);
      idx = allIdx[origPositions.indexOf(bestOrig)];
    }
  }
  if (idx === -1) {
    const selAlpha = selStripped.replace(/[^a-zA-Z0-9]/g, "");
    const concatAlpha = concatStrippedStr.replace(/[^a-zA-Z0-9]/g, "");
    if (selAlpha.length >= 2) {
      let alphaIdx = concatAlpha.indexOf(selAlpha);
      if (alphaIdx === -1) {
        alphaIdx = concatAlpha.toLowerCase().indexOf(selAlpha.toLowerCase());
      }
      if (alphaIdx !== -1) {
        let alphaCount = 0;
        let mappedStart = -1;
        let mappedEnd = -1;
        for (let i = 0; i < concatStrippedStr.length; i++) {
          if (/[a-zA-Z0-9]/.test(concatStrippedStr[i])) {
            if (alphaCount === alphaIdx) mappedStart = i;
            if (alphaCount === alphaIdx + selAlpha.length - 1) {
              mappedEnd = i + 1;
              break;
            }
            alphaCount++;
          }
        }
        if (mappedStart !== -1 && mappedEnd !== -1) {
          idx = mappedStart;
          confidence = 0.96;
          const origStart2 = strippedToOriginal[mappedStart];
          const origEnd2 = strippedToOriginal[mappedEnd - 1] + 1;
          return resolveMatch(origStart2, origEnd2, boundaries, positionMap, confidence);
        }
      }
    }
  }
  if (idx === -1) return null;
  const origStart = strippedToOriginal[idx];
  const origEnd = strippedToOriginal[idx + selStripped.length - 1] + 1;
  return resolveMatch(origStart, origEnd, boundaries, positionMap, confidence);
}
function bookendMatch(normalized, concat, boundaries, positionMap) {
  const BOOKEND_LEN = 50;
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < BOOKEND_LEN * 2) return null;
  const prefix = selStripped.substring(0, BOOKEND_LEN);
  const suffix = selStripped.substring(selStripped.length - BOOKEND_LEN);
  const strippedToOriginal = [];
  const concatStrippedChars = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStrippedChars.push(concat[i]);
    }
  }
  const concatStripped = concatStrippedChars.join("");
  const concatStrippedLower = concatStripped.toLowerCase();
  const prefixLower = prefix.toLowerCase();
  const suffixLower = suffix.toLowerCase();
  const maxSpan = selStripped.length * 2;
  let searchFrom = 0;
  while (searchFrom < concatStripped.length) {
    let prefixIdx = concatStripped.indexOf(prefix, searchFrom);
    if (prefixIdx === -1) prefixIdx = concatStrippedLower.indexOf(prefixLower, searchFrom);
    if (prefixIdx === -1) break;
    const suffixSearchStart = prefixIdx + BOOKEND_LEN;
    let suffixIdx = concatStripped.indexOf(suffix, suffixSearchStart);
    if (suffixIdx === -1) suffixIdx = concatStrippedLower.indexOf(suffixLower, suffixSearchStart);
    if (suffixIdx !== -1) {
      const span = suffixIdx + BOOKEND_LEN - prefixIdx;
      if (span <= maxSpan) {
        const origStart = strippedToOriginal[prefixIdx];
        const origEnd = strippedToOriginal[suffixIdx + BOOKEND_LEN - 1] + 1;
        const startBoundary = boundaries.find((b) => b.charStart <= origStart && b.charEnd > origStart);
        const endBoundary = boundaries.find((b) => b.charStart < origEnd && b.charEnd >= origEnd);
        if (startBoundary && endBoundary && endBoundary.entryIdx - startBoundary.entryIdx <= 60) {
          return resolveMatch(origStart, origEnd, boundaries, positionMap, 0.92);
        }
      }
    }
    searchFrom = prefixIdx + 1;
  }
  return null;
}
function resolveMatch(matchStart, matchEnd, boundaries, positionMap, confidence) {
  const startBoundary = boundaries.find((b) => b.charStart <= matchStart && b.charEnd > matchStart);
  const endBoundary = boundaries.find((b) => b.charStart < matchEnd && b.charEnd >= matchEnd);
  if (!startBoundary || !endBoundary) return null;
  const startEntry = positionMap[startBoundary.entryIdx];
  const endEntry = positionMap[endBoundary.entryIdx];
  return {
    citation: formatCitation(startEntry, endEntry),
    startEntry,
    endEntry,
    confidence
  };
}
function formatCitation(startEntry, endEntry) {
  const startCol = startEntry.column;
  const startLine = startEntry.lineNumber;
  const endCol = endEntry.column;
  const endLine = endEntry.lineNumber;
  if (startCol === endCol && startLine === endLine) {
    return `${startCol}:${startLine}`;
  } else if (startCol === endCol) {
    return `${startCol}:${startLine}-${endLine}`;
  } else {
    return `${startCol}:${startLine}-${endCol}:${endLine}`;
  }
}
function fuzzySubstringMatch(needle, haystack) {
  const n = needle.length;
  if (n === 0 || n > 100) return null;
  const maxDistance = Math.floor(n * 0.2);
  let bestSimilarity = 0;
  let bestStart = -1;
  let bestEnd = -1;
  const windowMin = Math.max(1, n - maxDistance);
  const windowMax = n + maxDistance;
  for (let windowSize = windowMin; windowSize <= windowMax; windowSize++) {
    for (let start = 0; start <= haystack.length - windowSize; start++) {
      const candidate = haystack.substring(start, start + windowSize);
      const distance = levenshtein(needle, candidate);
      const similarity = 1 - distance / Math.max(n, windowSize);
      if (similarity > bestSimilarity) {
        bestSimilarity = similarity;
        bestStart = start;
        bestEnd = start + windowSize;
      }
    }
  }
  if (bestSimilarity >= 0.8) {
    return { start: bestStart, end: bestEnd, similarity: bestSimilarity };
  }
  return null;
}
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}
var GUTTER_VALUES = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65];
function stripGutterNumbers(concat) {
  const survive = new Uint8Array(concat.length).fill(1);
  for (const n of GUTTER_VALUES) {
    const numStr = String(n);
    const len = numStr.length;
    for (let pos = 0; pos <= concat.length - len; pos++) {
      if (concat.substring(pos, pos + len) === numStr) {
        const before = pos === 0 || concat[pos - 1] === " ";
        const after = pos + len === concat.length || concat[pos + len] === " ";
        if (before && after) {
          for (let k = pos; k < pos + len; k++) survive[k] = 0;
        }
      }
    }
  }
  const preCollapseToOrig = [];
  let preCollapse = "";
  for (let i = 0; i < concat.length; i++) {
    if (survive[i]) {
      preCollapseToOrig.push(i);
      preCollapse += concat[i];
    }
  }
  const strippedToOrig = [];
  let stripped = "";
  let prevWasSpace = false;
  for (let i = 0; i < preCollapse.length; i++) {
    const ch = preCollapse[i];
    if (ch === " ") {
      if (!prevWasSpace && stripped.length > 0) {
        strippedToOrig.push(preCollapseToOrig[i]);
        stripped += ch;
        prevWasSpace = true;
      }
    } else {
      strippedToOrig.push(preCollapseToOrig[i]);
      stripped += ch;
      prevWasSpace = false;
    }
  }
  if (stripped.endsWith(" ")) {
    stripped = stripped.slice(0, -1);
    strippedToOrig.pop();
  }
  const changed = stripped !== concat;
  return { stripped, strippedToOrig, changed };
}
function gutterTolerantMatch(selection, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const { stripped, strippedToOrig, changed } = stripGutterNumbers(concat);
  if (!changed) return null;
  const origToStripped = new Int32Array(concat.length).fill(-1);
  for (let si = 0; si < strippedToOrig.length; si++) {
    origToStripped[strippedToOrig[si]] = si;
  }
  const remappedBoundaries = boundaries.map((b) => {
    let newStart = origToStripped[b.charStart];
    if (newStart === -1) {
      for (let j = b.charStart; j < concat.length; j++) {
        if (origToStripped[j] !== -1) {
          newStart = origToStripped[j];
          break;
        }
      }
    }
    if (newStart === -1) newStart = 0;
    let newEnd = -1;
    for (let j = b.charEnd - 1; j >= b.charStart; j--) {
      if (origToStripped[j] !== -1) {
        newEnd = origToStripped[j] + 1;
        break;
      }
    }
    if (newEnd === -1) newEnd = newStart + 1;
    return { charStart: newStart, charEnd: newEnd, entryIdx: b.entryIdx };
  });
  const exactPositions = findAllOccurrences(stripped, selection);
  if (exactPositions.length > 0) {
    const bestPos = pickBestByContext(exactPositions, selection.length, stripped, contextBefore, contextAfter);
    const result = resolveMatch(bestPos, bestPos + selection.length, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  const wsResult = whitespaceStrippedMatch(selection, stripped, remappedBoundaries, positionMap, contextBefore, contextAfter);
  if (wsResult) return { ...wsResult, confidence: 0.85 };
  if (selection.length > 60) {
    const beResult = bookendMatch(selection, stripped, remappedBoundaries, positionMap);
    if (beResult) return { ...beResult, confidence: 0.85 };
  }
  const fuzzyResult = fuzzySubstringMatch(selection, stripped);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    const result = resolveMatch(fuzzyResult.start, fuzzyResult.end, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  return null;
}
function matchAndCite(selectedText, positionMap, contextBefore = "", contextAfter = "") {
  let normalized = normalizeText(selectedText);
  if (!normalized || normalized.length < 2) return null;
  if (!positionMap || positionMap.length === 0) return null;
  normalized = normalized.replace(/- ([a-z])/g, "$1");
  const { text: ocrNormalized, changed: selChanged } = normalizeOcr(normalized);
  const { concat, boundaries } = buildConcat(positionMap);
  function applyPenaltyIfNeeded(result) {
    if (!result || !selChanged) return result;
    return { ...result, confidence: result.confidence - 0.02 };
  }
  const allPositions = findAllOccurrences(concat, ocrNormalized);
  if (allPositions.length > 0) {
    const bestPos = pickBestByContext(allPositions, ocrNormalized.length, concat, contextBefore, contextAfter);
    const matchEnd = bestPos + ocrNormalized.length;
    return applyPenaltyIfNeeded(resolveMatch(bestPos, matchEnd, boundaries, positionMap, 1));
  }
  const strippedResult = whitespaceStrippedMatch(ocrNormalized, concat, boundaries, positionMap, contextBefore, contextAfter);
  if (strippedResult) return applyPenaltyIfNeeded(strippedResult);
  if (ocrNormalized.length > 60) {
    const bookendResult = bookendMatch(ocrNormalized, concat, boundaries, positionMap);
    if (bookendResult) return applyPenaltyIfNeeded(bookendResult);
  }
  const fuzzyResult = fuzzySubstringMatch(ocrNormalized, concat);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    return applyPenaltyIfNeeded(resolveMatch(
      fuzzyResult.start,
      fuzzyResult.end,
      boundaries,
      positionMap,
      fuzzyResult.similarity
    ));
  }
  const gutterResult = gutterTolerantMatch(
    ocrNormalized,
    concat,
    boundaries,
    positionMap,
    contextBefore,
    contextAfter
  );
  if (gutterResult) return gutterResult;
  return null;
}

// src/offscreen/offscreen.js
var WORKER_URL = "https://pct.tonyrowles.com";
var PROXY_TOKEN = "4509b9943f831fb140eb0c3a7304f23cc6f72e41b5e5f8c800a42e94f09cadbe";
var CACHE_VERSION = "v3";
async function readTestModeOverrides() {
  try {
    const result = await chrome.storage.local.get(["pct_test_cache_version", "pct_test_mode"]);
    return {
      cacheVersion: result.pct_test_cache_version || CACHE_VERSION,
      testMode: result.pct_test_mode === true
    };
  } catch {
    return { cacheVersion: CACHE_VERSION, testMode: false };
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === MSG.FETCH_PDF) {
    fetchPdfWithRetry(message.pdfUrl, message.patentId);
  } else if (message.type === MSG.PARSE_PDF) {
    parsePdf(message.patentId);
  } else if (message.type === MSG.LOOKUP_POSITION && message.tabId) {
    lookupPosition(
      message.selectedText,
      message.patentId,
      message.tabId,
      message.contextBefore || "",
      message.contextAfter || ""
    );
  } else if (message.type === MSG.FETCH_USPTO_PDF) {
    fetchUsptoWithRetry(message.patentId);
  } else if (message.type === MSG.CHECK_CACHE) {
    handleCheckCache(message.patentId, message.pdfUrl);
  } else if (message.type === MSG.UPLOAD_TO_CACHE) {
    uploadToCache(message.patentId);
  }
});
async function parsePdf(patentId) {
  try {
    const db = await openDb();
    const record = await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readonly");
      const store = tx.objectStore("pdfs");
      const request = store.get(patentId);
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = (event) => {
        reject(new Error(`IndexedDB read failed: ${event.target.error}`));
      };
      tx.oncomplete = () => {
        db.close();
      };
    });
    if (!record || !record.pdf) {
      throw new Error(`No PDF found in IndexedDB for ${patentId}`);
    }
    const arrayBuffer = await record.pdf.arrayBuffer();
    const pageResults = await extractTextFromPdf(arrayBuffer);
    const positionMap = buildPositionMap(pageResults);
    if (positionMap.length === 0) {
      const totalItems = pageResults.reduce((sum, p) => sum + p.items.length, 0);
      if (totalItems > 0) {
        console.warn(`[Offscreen] Patent has ${totalItems} text items but no two-column pages detected`);
      }
    }
    const dbWrite = await openDb();
    await new Promise((resolve, reject) => {
      const tx = dbWrite.transaction("pdfs", "readwrite");
      const store = tx.objectStore("pdfs");
      store.put({
        patentId: record.patentId,
        pdf: record.pdf,
        timestamp: record.timestamp,
        textItems: pageResults,
        positionMap,
        positionMapMeta: {
          totalLines: positionMap.length,
          totalColumns: positionMap.length > 0 ? positionMap[positionMap.length - 1].column : 0,
          hasClaimsSection: positionMap.some((e) => e.section === "claims"),
          builtAt: Date.now()
        }
      });
      tx.oncomplete = () => {
        dbWrite.close();
        resolve();
      };
      tx.onerror = (event) => {
        dbWrite.close();
        reject(new Error(`IndexedDB write failed: ${event.target.error}`));
      };
    });
    chrome.runtime.sendMessage({
      type: MSG.PARSE_RESULT,
      success: true,
      patentId,
      pageCount: pageResults.length,
      lineCount: positionMap.length,
      columnCount: positionMap.length > 0 ? positionMap[positionMap.length - 1].column : 0
    });
  } catch (error) {
    if (error.message === "NO_TEXT_LAYER") {
      chrome.runtime.sendMessage({
        type: MSG.PARSE_RESULT,
        success: false,
        patentId,
        error: "no-text-layer"
      });
    } else {
      console.error(`[Offscreen] PDF parse error for ${patentId}:`, error);
      chrome.runtime.sendMessage({
        type: MSG.PARSE_RESULT,
        success: false,
        patentId,
        error: error.message
      });
    }
  }
}
async function fetchPdfWithRetry(pdfUrl, patentId, retries = 1) {
  try {
    const response = await fetch(pdfUrl);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    const blob = await response.blob();
    await storePdfInIndexedDB(patentId, blob);
    chrome.runtime.sendMessage({
      type: MSG.PDF_FETCH_RESULT,
      success: true,
      patentId
    });
  } catch (error) {
    if (retries > 0) {
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      return fetchPdfWithRetry(pdfUrl, patentId, retries - 1);
    }
    chrome.runtime.sendMessage({
      type: MSG.PDF_FETCH_RESULT,
      success: false,
      patentId,
      error: error.message
    });
  }
}
async function fetchUsptoWithRetry(patentId, retries = 1) {
  try {
    const workerUrl = `${WORKER_URL}?patent=${encodeURIComponent(patentId)}`;
    const response = await fetch(workerUrl, {
      headers: { "Authorization": `Bearer ${PROXY_TOKEN}` }
    });
    if (!response.ok) {
      const errorText = await response.text().catch(() => `HTTP ${response.status}`);
      throw new Error(errorText);
    }
    const blob = await response.blob();
    await storePdfInIndexedDB(patentId, blob);
    chrome.runtime.sendMessage({
      type: MSG.USPTO_FETCH_RESULT,
      success: true,
      patentId
    });
  } catch (error) {
    if (retries > 0) {
      await new Promise((r) => setTimeout(r, 1e3));
      return fetchUsptoWithRetry(patentId, retries - 1);
    }
    chrome.runtime.sendMessage({
      type: MSG.USPTO_FETCH_RESULT,
      success: false,
      patentId,
      error: error.message
    });
  }
}
async function checkCache(patentId) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 3e3);
  try {
    const { cacheVersion } = await readTestModeOverrides();
    const url = `${WORKER_URL}/cache?patent=${encodeURIComponent(patentId)}&v=${cacheVersion}`;
    const response = await fetch(url, {
      headers: { "Authorization": `Bearer ${PROXY_TOKEN}` },
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!response.ok) return null;
    return await response.json();
  } catch (err) {
    clearTimeout(timeoutId);
    console.warn("[Offscreen] Cache check failed:", err.message);
    return null;
  }
}
async function handleCheckCache(patentId, pdfUrl) {
  console.log(`[Offscreen] Checking cache for ${patentId}`);
  const cached = await checkCache(patentId);
  if (cached && cached.entries && cached.meta) {
    console.log(`[Offscreen] Cache HIT for ${patentId} \u2014 ${cached.entries.length} entries`);
    await handleCacheHit(patentId, cached);
  } else {
    console.log(`[Offscreen] Cache MISS for ${patentId}`);
    chrome.runtime.sendMessage({
      type: MSG.CACHE_MISS,
      patentId,
      pdfUrl
      // pass through for service worker to continue PDF fetch
    });
  }
}
async function handleCacheHit(patentId, cachedData) {
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readwrite");
      const store = tx.objectStore("pdfs");
      store.put({
        patentId,
        pdf: null,
        // No PDF blob on cache hit
        timestamp: Date.now(),
        positionMap: cachedData.entries,
        positionMapMeta: cachedData.meta
      });
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = (e) => {
        db.close();
        reject(e);
      };
    });
    chrome.runtime.sendMessage({
      type: MSG.CACHE_HIT_RESULT,
      patentId,
      lineCount: cachedData.meta.totalLines,
      columnCount: cachedData.meta.totalColumns
    });
  } catch (err) {
    console.warn("[Offscreen] Cache hit IndexedDB write failed:", err.message);
    chrome.runtime.sendMessage({
      type: MSG.CACHE_MISS,
      patentId,
      pdfUrl: null
      // pdfUrl not available here; service worker will need to handle
    });
  }
}
async function uploadToCache(patentId) {
  try {
    const db = await openDb();
    const record = await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readonly");
      const store = tx.objectStore("pdfs");
      const request = store.get(patentId);
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(new Error(`IndexedDB read: ${event.target.error}`));
      tx.oncomplete = () => db.close();
    });
    if (!record?.positionMap || !record?.positionMapMeta) {
      console.warn("[Offscreen] No positionMap to upload for", patentId);
      return;
    }
    const entries = record.positionMap.map(({ text, column, lineNumber, page, section, hasWrapHyphen }) => ({
      text,
      column,
      lineNumber,
      page,
      section,
      hasWrapHyphen
    }));
    const payload = {
      entries,
      meta: {
        totalLines: record.positionMapMeta.totalLines,
        totalColumns: record.positionMapMeta.totalColumns,
        hasClaimsSection: record.positionMapMeta.hasClaimsSection
      },
      cachedAt: Date.now(),
      version: CACHE_VERSION
    };
    const { cacheVersion, testMode } = await readTestModeOverrides();
    const url = `${WORKER_URL}/cache?patent=${encodeURIComponent(patentId)}&v=${cacheVersion}`;
    const headers = {
      "Authorization": `Bearer ${PROXY_TOKEN}`,
      "Content-Type": "application/json"
    };
    if (testMode) headers["X-PCT-Test-Mode"] = "true";
    const resp = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(payload)
    });
    console.log(`[Offscreen] Cache upload for ${patentId}: ${resp.status} ${resp.statusText}`);
  } catch (err) {
    console.warn("[Offscreen] Cache upload failed:", err.message);
  }
}
function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("patent-cite-tool", 1);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains("pdfs")) {
        db.createObjectStore("pdfs", { keyPath: "patentId" });
      }
    };
    request.onsuccess = (event) => {
      resolve(event.target.result);
    };
    request.onerror = (event) => {
      reject(new Error(`IndexedDB open failed: ${event.target.error}`));
    };
  });
}
async function storePdfInIndexedDB(patentId, blob) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("pdfs", "readwrite");
    const store = tx.objectStore("pdfs");
    store.put({
      patentId,
      pdf: blob,
      timestamp: Date.now()
    });
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = (event) => {
      db.close();
      reject(new Error(`IndexedDB write failed: ${event.target.error}`));
    };
  });
}
async function lookupPosition(selectedText, patentId, tabId, contextBefore, contextAfter) {
  try {
    const db = await openDb();
    const record = await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readonly");
      const store = tx.objectStore("pdfs");
      const request = store.get(patentId);
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(new Error(`IndexedDB read: ${event.target.error}`));
      tx.oncomplete = () => db.close();
    });
    if (!record || !record.positionMap || record.positionMap.length === 0) {
      chrome.runtime.sendMessage({
        type: MSG.CITATION_RESULT,
        tabId,
        success: false,
        error: "no-position-map"
      });
      return;
    }
    const pm = record.positionMap;
    const result = matchAndCite(selectedText, pm, contextBefore, contextAfter);
    if (result) {
      chrome.runtime.sendMessage({
        type: MSG.CITATION_RESULT,
        tabId,
        success: true,
        citation: result.citation,
        confidence: result.confidence,
        startEntry: {
          column: result.startEntry.column,
          lineNumber: result.startEntry.lineNumber,
          page: result.startEntry.page,
          section: result.startEntry.section
        },
        endEntry: {
          column: result.endEntry.column,
          lineNumber: result.endEntry.lineNumber,
          page: result.endEntry.page,
          section: result.endEntry.section
        }
      });
    } else {
      chrome.runtime.sendMessage({
        type: MSG.CITATION_RESULT,
        tabId,
        success: false,
        error: "no-match"
      });
    }
  } catch (error) {
    console.error("[Offscreen] Lookup error:", error);
    chrome.runtime.sendMessage({
      type: MSG.CITATION_RESULT,
      tabId,
      success: false,
      error: error.message
    });
  }
}
