// src/shared/constants.js
var MSG = {
  PATENT_PAGE_DETECTED: "patent-page-detected",
  PDF_LINK_FOUND: "pdf-link-found",
  PDF_LINK_NOT_FOUND: "pdf-link-not-found",
  FETCH_PDF: "fetch-pdf",
  PDF_FETCH_RESULT: "pdf-fetch-result",
  PARSE_PDF: "parse-pdf",
  PARSE_RESULT: "parse-result",
  GET_STATUS: "get-status",
  LOOKUP_POSITION: "lookup-position",
  CITATION_RESULT: "citation-result",
  GENERATE_CITATION: "generate-citation",
  FETCH_USPTO_PDF: "fetch-uspto-pdf",
  USPTO_FETCH_RESULT: "uspto-fetch-result",
  CHECK_CACHE: "check-cache",
  CACHE_HIT_RESULT: "cache-hit-result",
  CACHE_MISS: "cache-miss",
  UPLOAD_TO_CACHE: "upload-to-cache",
  SUBMIT_REPORT: "submit-report"
  // PAY-05
};
var STATUS = {
  IDLE: "idle",
  FETCHING: "fetching",
  READY: "ready",
  PARSING: "parsing",
  PARSED: "parsed",
  NO_TEXT_LAYER: "no-text-layer",
  ERROR: "error",
  UNAVAILABLE: "unavailable"
};
var PATENT_TYPE = {
  GRANT: "grant",
  APPLICATION: "application"
};
var REPORT_CATEGORIES = Object.freeze([
  "inaccurate_citation",
  "no_match",
  "tool_not_working",
  "other"
]);
var WORKER_REPORT_URL = "https://pct.tonyrowles.com/report";

// src/shared/report-transport.js
var PROXY_TOKEN = "4509b9943f831fb140eb0c3a7304f23cc6f72e41b5e5f8c800a42e94f09cadbe";
var BACKOFF_MS = [2e3, 8e3, 3e4];
var MAX_ATTEMPTS = 3;
var RATE_LIMIT_MAX = 5;
var RATE_LIMIT_WINDOW_MS = 6e5;
var QUEUE_KEY = "bugReportQueue";
var RATE_KEY = "bugReportRateLimitWindow";
var QUEUE_CAP = 20;
var QUEUE_TTL_MS = 6048e5;
var drainingQueue = null;
var storageLock = Promise.resolve();
function withStorageLock(fn) {
  const run = storageLock.then(fn, fn);
  storageLock = run.then(() => {
  }, () => {
  });
  return run;
}
async function checkAndUpdateRateLimit() {
  return withStorageLock(async () => {
    const now = Date.now();
    const stored = await chrome.storage.local.get(RATE_KEY);
    const raw = stored[RATE_KEY];
    const window2 = (Array.isArray(raw) ? raw : []).filter((ts) => now - ts < RATE_LIMIT_WINDOW_MS);
    if (window2.length >= RATE_LIMIT_MAX) {
      return false;
    }
    window2.push(now);
    await chrome.storage.local.set({ [RATE_KEY]: window2 });
    return true;
  });
}
async function submitReport(payload) {
  if (payload == null) {
    return { ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true };
  }
  const allowed = await checkAndUpdateRateLimit();
  if (!allowed) {
    return { ok: false, queued: false, fingerprint: null, rateLimited: true, dropped: false };
  }
  const entry = {
    payload,
    attemptCount: 0,
    nextAttemptAt: 0,
    // 0 = immediately eligible for drain
    enqueuedAt: Date.now()
  };
  await _enqueueEntry(entry);
  const result = await attemptEntry(entry);
  if (result.outcome === "success") {
    return { ok: true, queued: false, fingerprint: result.fingerprint, rateLimited: false, dropped: false };
  } else if (result.outcome === "queued") {
    return { ok: false, queued: true, fingerprint: null, rateLimited: false, dropped: false };
  } else {
    return { ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true };
  }
}
async function attemptEntry(entry) {
  let resp;
  let networkError = false;
  try {
    resp = await fetch(WORKER_REPORT_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${PROXY_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(entry.payload)
    });
  } catch {
    networkError = true;
  }
  if (!networkError && resp.ok) {
    let fingerprint = null;
    try {
      const body = await resp.json();
      fingerprint = body.fingerprint ?? null;
    } catch {
    }
    await _removeEntryFromQueue(entry);
    return { outcome: "success", fingerprint };
  }
  if (!networkError && resp.status >= 400 && resp.status < 500 && resp.status !== 429) {
    await _removeEntryFromQueue(entry);
    return { outcome: "dropped" };
  }
  entry.attemptCount += 1;
  const backoffMs = BACKOFF_MS[entry.attemptCount - 1] ?? BACKOFF_MS[BACKOFF_MS.length - 1];
  entry.nextAttemptAt = Date.now() + backoffMs;
  if (entry.attemptCount >= MAX_ATTEMPTS) {
    await _removeEntryFromQueue(entry);
    return { outcome: "dropped" };
  }
  await _updateEntryInQueue(entry);
  setTimeout(() => {
    drainQueueOnce().catch(() => {
    });
  }, backoffMs);
  return { outcome: "queued" };
}
async function _enqueueEntry(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const now = Date.now();
    let queue = (Array.isArray(raw) ? raw : []).filter((e) => now - e.enqueuedAt < QUEUE_TTL_MS);
    queue.push(entry);
    if (queue.length > QUEUE_CAP) {
      queue.sort((a, b) => a.enqueuedAt - b.enqueuedAt);
      queue = queue.slice(queue.length - QUEUE_CAP);
    }
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function _removeEntryFromQueue(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const queue = (Array.isArray(raw) ? raw : []).filter((e) => e.enqueuedAt !== entry.enqueuedAt);
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function _updateEntryInQueue(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const queue = (Array.isArray(raw) ? raw : []).map(
      (e) => e.enqueuedAt === entry.enqueuedAt ? entry : e
    );
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function drainQueueOnce() {
  if (drainingQueue) {
    return drainingQueue;
  }
  drainingQueue = _doDrain();
  try {
    await drainingQueue;
  } finally {
    drainingQueue = null;
  }
}
async function _doDrain() {
  const eligible = await withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    if (!Array.isArray(raw) || raw.length === 0) return [];
    const now = Date.now();
    const live = raw.filter((e) => now - e.enqueuedAt < QUEUE_TTL_MS);
    if (live.length !== raw.length) {
      await chrome.storage.local.set({ [QUEUE_KEY]: live });
    }
    return live.filter((e) => e.nextAttemptAt <= now);
  });
  for (const entry of eligible) {
    await attemptEntry(entry);
  }
}

// src/content/report-dialog.js
var ERROR_BUFFER_KEY = "bugReportErrorBuffer";
var BUFFER_MAX = 20;
var EXTENSION_PREFIXES = ["[SW]", "[PCT]", "[Offscreen]", "[Firefox]", "[BG]"];
var _bufferInstalled = false;
function isExtensionTagged(args) {
  const first = args[0];
  if (typeof first !== "string") return false;
  return EXTENSION_PREFIXES.some((p) => first.startsWith(p));
}
async function appendToBuffer(level, args) {
  try {
    const message = args.map((a) => typeof a === "string" ? a : JSON.stringify(a)).join(" ").substring(0, 500);
    const entry = { level, message, ts: Date.now() };
    const stored = await chrome.storage.local.get(ERROR_BUFFER_KEY);
    const buf = Array.isArray(stored[ERROR_BUFFER_KEY]) ? stored[ERROR_BUFFER_KEY] : [];
    buf.push(entry);
    const trimmed = buf.length > BUFFER_MAX ? buf.slice(buf.length - BUFFER_MAX) : buf;
    await chrome.storage.local.set({ [ERROR_BUFFER_KEY]: trimmed });
  } catch {
  }
}
function installErrorBuffer() {
  if (_bufferInstalled) return;
  _bufferInstalled = true;
  const origError = console.error.bind(console);
  const origWarn = console.warn.bind(console);
  console.error = function(...args) {
    origError(...args);
    if (isExtensionTagged(args)) appendToBuffer("error", args).catch(() => {
    });
  };
  console.warn = function(...args) {
    origWarn(...args);
    if (isExtensionTagged(args)) appendToBuffer("warn", args).catch(() => {
    });
  };
}

// src/background/service-worker.js
installErrorBuffer();
var ICON_PATHS = {
  partial: {
    16: "/icons/icon-partial-16.png",
    32: "/icons/icon-partial-32.png",
    48: "/icons/icon-partial-48.png",
    128: "/icons/icon-partial-128.png"
  },
  active: {
    16: "/icons/icon-active-16.png",
    32: "/icons/icon-active-32.png",
    48: "/icons/icon-active-48.png",
    128: "/icons/icon-active-128.png"
  }
};
function setTabIcon(tabId, state) {
  if (!tabId) return;
  chrome.action.setIcon({ path: ICON_PATHS[state], tabId });
}
var creatingOffscreen = null;
async function ensureOffscreenDocument() {
  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL("offscreen/offscreen.html")]
  });
  if (contexts.length > 0) {
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: "offscreen/offscreen.html",
    reasons: ["BLOBS"],
    justification: "Fetch and store patent PDF for citation processing"
  });
  await creatingOffscreen;
  creatingOffscreen = null;
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.action.disable();
  chrome.declarativeContent.onPageChanged.removeRules(void 0, () => {
    chrome.declarativeContent.onPageChanged.addRules([
      {
        conditions: [
          new chrome.declarativeContent.PageStateMatcher({
            pageUrl: {
              hostEquals: "patents.google.com",
              pathPrefix: "/patent/US",
              schemes: ["https"]
            }
          })
        ],
        actions: [new chrome.declarativeContent.ShowAction()]
      }
    ]);
  });
  chrome.contextMenus.create({
    id: "get-patent-citation",
    title: "Get Citation",
    contexts: ["selection"],
    documentUrlPatterns: ["https://patents.google.com/patent/US*"]
  });
  drainQueueOnce().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  drainQueueOnce().catch(() => {
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "get-patent-citation" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: MSG.GENERATE_CITATION,
      selectedText: info.selectionText
    }).catch((err) => console.warn("[SW] Context menu send failed:", err.message));
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  drainQueueOnce().catch(() => {
  });
  const tabId = sender.tab?.id;
  if (message.type === MSG.PDF_LINK_FOUND) {
    handlePdfLinkFound(message, tabId);
  } else if (message.type === MSG.PDF_LINK_NOT_FOUND) {
    handlePdfUnavailable(message, tabId);
  } else if (message.type === MSG.PDF_FETCH_RESULT) {
    handlePdfFetchResult(message);
  } else if (message.type === MSG.PARSE_RESULT) {
    handleParseResult(message);
  } else if (message.type === MSG.LOOKUP_POSITION) {
    handleLookupPosition(message, sender);
  } else if (message.type === MSG.CITATION_RESULT) {
    handleCitationResult(message);
  } else if (message.type === MSG.USPTO_FETCH_RESULT) {
    handleUsptoFetchResult(message);
  } else if (message.type === MSG.CACHE_HIT_RESULT) {
    handleCacheHitResult(message);
  } else if (message.type === MSG.CACHE_MISS) {
    handleCacheMiss(message);
  } else if (message.type === MSG.GET_STATUS) {
    handleGetStatus(sendResponse);
    return true;
  } else if (message.type === MSG.SUBMIT_REPORT) {
    submitReport(message.payload).then((result) => sendResponse(result)).catch(() => sendResponse({ ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true }));
    return true;
  }
});
async function handlePdfLinkFound(message, tabId) {
  const { patentId, patentType, kindCode, pdfUrl } = message;
  await chrome.storage.local.set({
    currentPatent: {
      patentId,
      patentType,
      kindCode,
      pdfUrl,
      tabId,
      status: STATUS.FETCHING,
      source: "google",
      error: null
    }
  });
  setTabIcon(tabId, "partial");
  await ensureOffscreenDocument();
  chrome.runtime.sendMessage({
    type: MSG.CHECK_CACHE,
    patentId,
    pdfUrl
    // pass through so CACHE_MISS can continue the fetch
  }).catch((err) => console.warn("[SW] CHECK_CACHE send failed:", err.message));
}
async function handlePdfUnavailable(message, tabId) {
  const { patentId, patentType, kindCode } = message;
  if (patentType === PATENT_TYPE.GRANT) {
    console.log(`[SW] No Google PDF link for ${patentId}, checking cache before USPTO fallback`);
    await chrome.storage.local.set({
      currentPatent: {
        patentId,
        patentType,
        kindCode,
        pdfUrl: null,
        tabId,
        status: STATUS.FETCHING,
        source: null,
        error: null
      }
    });
    await ensureOffscreenDocument();
    chrome.runtime.sendMessage({
      type: MSG.CHECK_CACHE,
      patentId,
      pdfUrl: null
      // no Google PDF — CACHE_MISS will trigger USPTO fallback
    }).catch((err) => console.warn("[SW] CHECK_CACHE send failed:", err.message));
  } else {
    await chrome.storage.local.set({
      currentPatent: {
        patentId,
        patentType,
        kindCode,
        pdfUrl: null,
        tabId,
        status: STATUS.UNAVAILABLE,
        error: null
      }
    });
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
  }
}
async function handlePdfFetchResult(message) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  if (message.success) {
    patent.status = STATUS.PARSING;
    patent.error = null;
    await chrome.storage.local.set({ currentPatent: patent });
    chrome.runtime.sendMessage({
      type: MSG.PARSE_PDF,
      patentId: patent.patentId
    }).catch((err) => console.warn("[SW] PARSE_PDF send failed:", err.message));
  } else {
    if (patent.patentType === PATENT_TYPE.GRANT && patent.source !== "uspto") {
      console.log(`[SW] Google PDF fetch failed, trying USPTO fallback for ${patent.patentId}`);
      patent.status = STATUS.FETCHING;
      patent.source = null;
      patent.error = null;
      await chrome.storage.local.set({ currentPatent: patent });
      chrome.runtime.sendMessage({
        type: MSG.FETCH_USPTO_PDF,
        patentId: patent.patentId
      }).catch((err) => console.warn("[SW] FETCH_USPTO_PDF send failed:", err.message));
    } else {
      patent.status = STATUS.ERROR;
      patent.error = message.error;
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#EF4444" });
      await chrome.storage.local.set({ currentPatent: patent });
    }
  }
}
async function handleParseResult(message) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  if (message.success) {
    patent.status = STATUS.PARSED;
    patent.lineCount = message.lineCount;
    patent.columnCount = message.columnCount;
    patent.error = null;
    chrome.action.setBadgeText({ text: "" });
    setTabIcon(patent.tabId, "active");
    await chrome.storage.local.set({ currentPatent: patent });
    chrome.runtime.sendMessage({
      type: MSG.UPLOAD_TO_CACHE,
      patentId: patent.patentId
    }).catch(() => {
    });
  } else if (message.error === "no-text-layer") {
    if (patent.patentType === PATENT_TYPE.GRANT && patent.source !== "uspto") {
      console.log(`[SW] Google PDF has no text layer, trying USPTO fallback for ${patent.patentId}`);
      patent.status = STATUS.FETCHING;
      patent.source = null;
      patent.error = null;
      await chrome.storage.local.set({ currentPatent: patent });
      await ensureOffscreenDocument();
      chrome.runtime.sendMessage({
        type: MSG.FETCH_USPTO_PDF,
        patentId: patent.patentId
      }).catch((err) => console.warn("[SW] FETCH_USPTO_PDF send failed:", err.message));
    } else {
      patent.status = STATUS.NO_TEXT_LAYER;
      patent.error = null;
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
      await chrome.storage.local.set({ currentPatent: patent });
    }
  } else {
    patent.status = STATUS.ERROR;
    patent.error = message.error;
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#EF4444" });
    await chrome.storage.local.set({ currentPatent: patent });
  }
}
async function handleUsptoFetchResult(message) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  if (message.success) {
    patent.status = STATUS.PARSING;
    patent.source = "uspto";
    patent.error = null;
    await chrome.storage.local.set({ currentPatent: patent });
    chrome.runtime.sendMessage({
      type: MSG.PARSE_PDF,
      patentId: patent.patentId
    }).catch((err) => console.warn("[SW] PARSE_PDF send failed:", err.message));
  } else {
    patent.status = STATUS.UNAVAILABLE;
    patent.error = null;
    await chrome.storage.local.set({ currentPatent: patent });
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
  }
}
async function handleCacheHitResult(message) {
  console.log(`[SW] Cache HIT for ${message.patentId} \u2014 skipping PDF fetch/parse`);
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  patent.status = STATUS.PARSED;
  patent.source = null;
  patent.lineCount = message.lineCount;
  patent.columnCount = message.columnCount;
  patent.error = null;
  chrome.action.setBadgeText({ text: "" });
  setTabIcon(patent.tabId, "active");
  await chrome.storage.local.set({ currentPatent: patent });
}
async function handleCacheMiss(message) {
  const { patentId, pdfUrl } = message;
  console.log(`[SW] Cache miss for ${patentId}`);
  if (pdfUrl) {
    console.log(`[SW] Fetching Google PDF for ${patentId}`);
    chrome.runtime.sendMessage({
      type: MSG.FETCH_PDF,
      pdfUrl,
      patentId
    }).catch((err) => console.warn("[SW] FETCH_PDF send failed:", err.message));
  } else {
    console.log(`[SW] No Google PDF, trying USPTO fallback for ${patentId}`);
    chrome.runtime.sendMessage({
      type: MSG.FETCH_USPTO_PDF,
      patentId
    }).catch((err) => console.warn("[SW] FETCH_USPTO_PDF send failed:", err.message));
  }
}
async function handleLookupPosition(message, sender) {
  const tabId = sender.tab?.id;
  if (!tabId) return;
  try {
    await ensureOffscreenDocument();
    await chrome.runtime.sendMessage({
      type: MSG.LOOKUP_POSITION,
      selectedText: message.selectedText,
      patentId: message.patentId,
      contextBefore: message.contextBefore || "",
      contextAfter: message.contextAfter || "",
      tabId
    });
  } catch (error) {
    console.warn("[SW] Lookup forward failed:", error.message);
    chrome.tabs.sendMessage(tabId, {
      type: MSG.CITATION_RESULT,
      success: false,
      error: "lookup-failed"
    }).catch(() => {
    });
  }
}
function handleCitationResult(message) {
  const { tabId, ...result } = message;
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, {
    type: MSG.CITATION_RESULT,
    ...result
  }).catch((err) => console.warn("[SW] CITATION_RESULT forward failed:", err.message));
}
async function handleGetStatus(sendResponse) {
  const data = await chrome.storage.local.get("currentPatent");
  sendResponse(data.currentPatent || null);
}
