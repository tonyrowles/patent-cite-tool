// src/shared/constants.js
var MSG = {
  PATENT_PAGE_DETECTED: "patent-page-detected",
  PDF_LINK_FOUND: "pdf-link-found",
  PDF_LINK_NOT_FOUND: "pdf-link-not-found",
  FETCH_PDF: "fetch-pdf",
  PDF_FETCH_RESULT: "pdf-fetch-result",
  PARSE_PDF: "parse-pdf",
  PARSE_RESULT: "parse-result",
  GET_STATUS: "get-status",
  LOOKUP_POSITION: "lookup-position",
  CITATION_RESULT: "citation-result",
  GENERATE_CITATION: "generate-citation",
  FETCH_USPTO_PDF: "fetch-uspto-pdf",
  USPTO_FETCH_RESULT: "uspto-fetch-result",
  CHECK_CACHE: "check-cache",
  CACHE_HIT_RESULT: "cache-hit-result",
  CACHE_MISS: "cache-miss",
  UPLOAD_TO_CACHE: "upload-to-cache",
  SUBMIT_REPORT: "submit-report"
  // PAY-05
};
var STATUS = {
  IDLE: "idle",
  FETCHING: "fetching",
  READY: "ready",
  PARSING: "parsing",
  PARSED: "parsed",
  NO_TEXT_LAYER: "no-text-layer",
  ERROR: "error",
  UNAVAILABLE: "unavailable"
};
var PATENT_TYPE = {
  GRANT: "grant",
  APPLICATION: "application"
};
var REPORT_CATEGORIES = Object.freeze([
  "inaccurate_citation",
  "no_match",
  "tool_not_working",
  "other"
]);
var WORKER_REPORT_URL = "https://pct.tonyrowles.com/report";

// src/offscreen/pdf-parser.js
import { getDocument, GlobalWorkerOptions } from "../lib/pdf.mjs";
GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("lib/pdf.worker.mjs");
async function hasTextLayer(pdf) {
  const pagesToCheck = Math.min(pdf.numPages, 5);
  let totalItems = 0;
  for (let i = 1; i <= pagesToCheck; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const nonEmpty = textContent.items.filter(
      (item) => item.str && item.str.trim().length > 0
    );
    totalItems += nonEmpty.length;
  }
  return totalItems >= 5;
}
async function extractTextFromPdf(pdfData) {
  const pdf = await getDocument({ data: pdfData, useSystemFonts: true }).promise;
  const hasText = await hasTextLayer(pdf);
  if (!hasText) {
    pdf.destroy();
    throw new Error("NO_TEXT_LAYER");
  }
  const results = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const viewport = page.getViewport({ scale: 1 });
    const pageItems = textContent.items.filter((item) => item.str && item.str.trim().length > 0).map((item) => ({
      text: item.str,
      x: item.transform[4],
      y: item.transform[5],
      width: item.width,
      height: item.height,
      fontName: item.fontName,
      hasEOL: item.hasEOL,
      pageNum: i,
      pageWidth: viewport.width,
      pageHeight: viewport.height
    }));
    results.push({
      pageNum: i,
      items: pageItems,
      pageWidth: viewport.width,
      pageHeight: viewport.height
    });
  }
  pdf.destroy();
  return results;
}

// src/offscreen/position-map-builder.js
function isTwoColumnPage(pageItems, pageWidth) {
  if (pageItems.length < 20) return false;
  const midX = pageWidth / 2;
  let leftCount = 0;
  let rightCount = 0;
  for (const item of pageItems) {
    if (item.x < midX) leftCount++;
    else rightCount++;
  }
  const total = leftCount + rightCount;
  if (total < 30) return false;
  const ratio = Math.min(leftCount, rightCount) / Math.max(leftCount, rightCount);
  return ratio > 0.3;
}
function findColumnBoundary(pageItems, pageWidth) {
  const buckets = new Array(Math.ceil(pageWidth)).fill(0);
  for (const item of pageItems) {
    const bucketIdx = Math.floor(item.x);
    if (bucketIdx >= 0 && bucketIdx < buckets.length) {
      buckets[bucketIdx]++;
    }
  }
  const searchStart = Math.floor(pageWidth * 0.25);
  const searchEnd = Math.ceil(pageWidth * 0.75);
  const pageMid = pageWidth / 2;
  const gaps = [];
  let currentGapStart = -1;
  for (let i = searchStart; i < searchEnd; i++) {
    if (buckets[i] === 0) {
      if (currentGapStart === -1) currentGapStart = i;
    } else {
      if (currentGapStart !== -1) {
        const width = i - currentGapStart;
        if (width >= 5) gaps.push({ start: currentGapStart, end: i, width });
        currentGapStart = -1;
      }
    }
  }
  if (currentGapStart !== -1) {
    const width = searchEnd - currentGapStart;
    if (width >= 5) gaps.push({ start: currentGapStart, end: searchEnd, width });
  }
  if (gaps.length === 0) return pageMid;
  let bestGap = gaps[0];
  let bestDist = Math.abs((gaps[0].start + gaps[0].end) / 2 - pageMid);
  for (let i = 1; i < gaps.length; i++) {
    const gapMid = (gaps[i].start + gaps[i].end) / 2;
    const dist = Math.abs(gapMid - pageMid);
    if (dist < bestDist) {
      bestDist = dist;
      bestGap = gaps[i];
    }
  }
  return (bestGap.start + bestGap.end) / 2;
}
function extractPrintedColumnNumbers(items, pageHeight, pageWidth) {
  const headerThreshold = pageHeight - 90;
  const midX = pageWidth / 2;
  const headerNumbers = [];
  for (const item of items) {
    if (item.y >= headerThreshold) {
      const text = item.text.trim();
      if (/^\d{1,3}$/.test(text)) {
        headerNumbers.push({ value: parseInt(text, 10), x: item.x });
      }
    }
  }
  if (headerNumbers.length === 0) return null;
  const leftNums = headerNumbers.filter((n) => n.x < midX).sort((a, b) => a.x - b.x);
  const rightNums = headerNumbers.filter((n) => n.x >= midX).sort((a, b) => a.x - b.x);
  let left, right;
  if (leftNums.length > 0 && rightNums.length > 0) {
    left = leftNums[0].value;
    right = rightNums[0].value;
  } else if (rightNums.length > 0 && leftNums.length === 0) {
    right = rightNums[0].value;
    left = right - 1;
  } else if (leftNums.length > 0 && rightNums.length === 0) {
    left = leftNums[0].value;
    right = left + 1;
  } else {
    return null;
  }
  if (right !== left + 1) return null;
  if (left < 1 || left % 2 !== 1) return null;
  return { left, right };
}
function filterGutterLineNumbers(items, boundary, pageWidth) {
  const pageMid = pageWidth / 2;
  return items.filter((item) => {
    const text = item.text.trim();
    if (!/^\d{1,2}$/.test(text)) return true;
    const num = parseInt(text, 10);
    if (num < 5 || num > 65 || num % 5 !== 0) return true;
    const nearBoundary = Math.abs(item.x - boundary) <= 40;
    const nearCenter = Math.abs(item.x - pageMid) <= 40;
    if (!nearBoundary && !nearCenter) return true;
    return false;
  });
}
function stripCrossBoundaryText(items, boundary) {
  const rightFragments = [];
  const gutterRe = /\s+\b(?:5|10|15|20|25|30|35|40|45|50|55|60|65)\b\s+(.*)$/;
  const cleaned = items.map((item) => {
    const itemEnd = item.x + item.width;
    if (itemEnd <= boundary + 20) return item;
    const m = item.text.match(gutterRe);
    const stripped = item.text.replace(gutterRe, "");
    if (m && stripped !== item.text) {
      const rightText = m[1];
      if (rightText && rightText.trim().length > 0) {
        const beforeLen = item.text.length - rightText.length;
        const rightX = Math.max(
          item.x + beforeLen / item.text.length * item.width,
          boundary + 1
        );
        rightFragments.push({
          ...item,
          text: rightText,
          x: rightX,
          width: rightText.length / item.text.length * item.width
        });
      }
      return { ...item, text: stripped, width: stripped.length / item.text.length * item.width };
    }
    return item;
  });
  return { items: cleaned, rightFragments };
}
function filterHeadersFooters(items, pageHeight) {
  const headerThreshold = pageHeight - 90;
  const footerThreshold = 40;
  return items.filter((item) => {
    return item.y > footerThreshold && item.y < headerThreshold;
  });
}
function clusterIntoLines(items, yTolerance = 3) {
  if (items.length === 0) return [];
  const sorted = [...items].sort((a, b) => b.y - a.y);
  const lines = [];
  let currentLine = [sorted[0]];
  let currentY = sorted[0].y;
  for (let i = 1; i < sorted.length; i++) {
    if (Math.abs(sorted[i].y - currentY) <= yTolerance) {
      currentLine.push(sorted[i]);
    } else {
      currentLine.sort((a, b) => a.x - b.x);
      lines.push(currentLine);
      currentLine = [sorted[i]];
      currentY = sorted[i].y;
    }
  }
  currentLine.sort((a, b) => a.x - b.x);
  lines.push(currentLine);
  return lines;
}
function buildLineEntry(lineItems, pageNum, column, lineNumber) {
  let text = "";
  for (let i = 0; i < lineItems.length; i++) {
    if (i > 0) {
      const prevEnd = lineItems[i - 1].x + lineItems[i - 1].width;
      const gap = lineItems[i].x - prevEnd;
      if (gap > 1 && !text.endsWith(" ")) {
        text += " ";
      }
    }
    text += lineItems[i].text;
  }
  const firstItem = lineItems[0];
  const lastItem = lineItems[lineItems.length - 1];
  return {
    page: pageNum,
    column,
    lineNumber,
    text,
    hasWrapHyphen: false,
    // Set in post-processing by detectWrapHyphens
    x: firstItem.x,
    y: firstItem.y,
    width: lastItem.x + lastItem.width - firstItem.x,
    height: Math.max(...lineItems.map((item) => item.height)),
    section: "description"
    // Default; updated by detectClaimsBoundary
  };
}
function detectClaimsBoundary(entries) {
  const claimsMarkers = [
    /what\s+is\s+claimed\s+is/i,
    /we\s+claim/i,
    /i\s+claim/i,
    /the\s+invention\s+claimed\s+is/i
  ];
  for (let i = 0; i < entries.length; i++) {
    for (const marker of claimsMarkers) {
      if (marker.test(entries[i].text)) {
        return i;
      }
    }
  }
  return -1;
}
function detectWrapHyphens(entries) {
  for (let i = 0; i < entries.length - 1; i++) {
    const current = entries[i];
    const next = entries[i + 1];
    if (current.column !== next.column) continue;
    if (current.text.endsWith("-")) {
      const nextFirstChar = next.text.trimStart().charAt(0);
      if (nextFirstChar && nextFirstChar === nextFirstChar.toLowerCase() && nextFirstChar !== nextFirstChar.toUpperCase()) {
        current.hasWrapHyphen = true;
      }
    }
  }
}
function extractGutterLineGrid(items, boundary, pageWidth) {
  const pageMid = pageWidth / 2;
  const markers = [];
  for (const item of items) {
    const text = item.text.trim();
    if (!/^\d{1,2}$/.test(text)) continue;
    const num = parseInt(text, 10);
    if (num < 5 || num > 65 || num % 5 !== 0) continue;
    const nearBoundary = Math.abs(item.x - boundary) <= 40;
    const nearCenter = Math.abs(item.x - pageMid) <= 40;
    if (!nearBoundary && !nearCenter) continue;
    markers.push({ lineNumber: num, y: item.y });
  }
  if (markers.length < 2) return null;
  const seen = /* @__PURE__ */ new Map();
  for (const m of markers) {
    if (!seen.has(m.lineNumber)) {
      seen.set(m.lineNumber, m);
    }
  }
  const unique = [...seen.values()];
  if (unique.length < 2) return null;
  unique.sort((a, b) => a.lineNumber - b.lineNumber);
  const perLineSpacings = [];
  for (let i = 1; i < unique.length; i++) {
    const lineDiff = unique[i].lineNumber - unique[i - 1].lineNumber;
    const yDiff = unique[i - 1].y - unique[i].y;
    if (lineDiff > 0 && yDiff > 0) {
      perLineSpacings.push(yDiff / lineDiff);
    }
  }
  if (perLineSpacings.length === 0) return null;
  perLineSpacings.sort((a, b) => a - b);
  const lineSpacing = perLineSpacings[Math.floor(perLineSpacings.length / 2)];
  const firstMarker = unique[0];
  const firstLineY = firstMarker.y + (firstMarker.lineNumber - 1) * lineSpacing;
  return { firstLineY, lineSpacing };
}
function assignLineNumbersByGrid(lines, entries, pageNum, column, grid) {
  for (const lineItems of lines) {
    const avgY = lineItems.reduce((sum, item) => sum + item.y, 0) / lineItems.length;
    const lineNumber = 1 + Math.round((grid.firstLineY - avgY) / grid.lineSpacing);
    entries.push(buildLineEntry(lineItems, pageNum, column, Math.max(1, lineNumber)));
  }
}
function assignLineNumbers(lines, entries, pageNum, column) {
  if (lines.length === 0) return;
  const lineYs = lines.map((lineItems) => {
    const sum = lineItems.reduce((s, item) => s + item.y, 0);
    return sum / lineItems.length;
  });
  const spacings = [];
  for (let i = 1; i < lineYs.length; i++) {
    const spacing = lineYs[i - 1] - lineYs[i];
    if (spacing > 0) spacings.push(spacing);
  }
  if (spacings.length === 0) {
    for (let i = 0; i < lines.length; i++) {
      entries.push(buildLineEntry(lines[i], pageNum, column, i + 1));
    }
    return;
  }
  spacings.sort((a, b) => a - b);
  const medianSpacing = spacings[Math.floor(spacings.length / 2)];
  let lineNumber = 1;
  entries.push(buildLineEntry(lines[0], pageNum, column, lineNumber));
  for (let i = 1; i < lines.length; i++) {
    const gap = lineYs[i - 1] - lineYs[i];
    const lineSpans = Math.max(1, Math.round(gap / medianSpacing));
    lineNumber += lineSpans;
    entries.push(buildLineEntry(lines[i], pageNum, column, lineNumber));
  }
}
function isLikelySpecPage(items, pageHeight) {
  const headerThreshold = pageHeight - 90;
  const headerText = items.filter((it) => it.y >= headerThreshold).map((it) => it.text).join(" ");
  if (headerText.includes("United States Patent")) return false;
  if (/Sheet\s+\d+\s+of\s+\d+/i.test(headerText)) return false;
  if (/\bPage\s+\d+\b/i.test(headerText)) return false;
  const bodyItems = items.filter((it) => it.y > 40 && it.y < headerThreshold);
  if (bodyItems.length < 80) return false;
  return true;
}
function processPageColumns(pageResult, colNums, entries) {
  const { pageNum, items, pageWidth, pageHeight } = pageResult;
  const boundary = findColumnBoundary(items, pageWidth);
  const filtered = filterHeadersFooters(items, pageHeight);
  if (filtered.length === 0) return;
  const grid = extractGutterLineGrid(filtered, boundary, pageWidth);
  const { items: strippedLeft, rightFragments } = stripCrossBoundaryText(
    filtered.filter((item) => item.x < boundary),
    boundary
  );
  const leftItems = filterGutterLineNumbers(strippedLeft, boundary, pageWidth);
  const rightItems = filterGutterLineNumbers(
    [...filtered.filter((item) => item.x >= boundary), ...rightFragments],
    boundary,
    pageWidth
  );
  const leftLines = clusterIntoLines(leftItems);
  if (grid) {
    assignLineNumbersByGrid(leftLines, entries, pageNum, colNums.left, grid);
  } else {
    assignLineNumbers(leftLines, entries, pageNum, colNums.left);
  }
  const rightLines = clusterIntoLines(rightItems);
  if (grid) {
    assignLineNumbersByGrid(rightLines, entries, pageNum, colNums.right, grid);
  } else {
    assignLineNumbers(rightLines, entries, pageNum, colNums.right);
  }
}
function buildPositionMap(pageResults) {
  const entries = [];
  let expectedLeftCol = 1;
  for (const pageResult of pageResults) {
    const { items, pageWidth, pageHeight } = pageResult;
    if (!isTwoColumnPage(items, pageWidth)) continue;
    const colNums = extractPrintedColumnNumbers(items, pageHeight, pageWidth);
    if (!colNums) continue;
    if (colNums.left !== expectedLeftCol) continue;
    expectedLeftCol = colNums.right + 1;
    processPageColumns(pageResult, colNums, entries);
  }
  if (entries.length === 0) {
    let inferredLeft = 1;
    for (const pageResult of pageResults) {
      const { items, pageWidth, pageHeight } = pageResult;
      if (!isTwoColumnPage(items, pageWidth)) continue;
      if (!isLikelySpecPage(items, pageHeight)) continue;
      const colNums = { left: inferredLeft, right: inferredLeft + 1 };
      inferredLeft += 2;
      processPageColumns(pageResult, colNums, entries);
    }
  }
  const claimsStart = detectClaimsBoundary(entries);
  if (claimsStart >= 0) {
    for (let i = claimsStart; i < entries.length; i++) {
      entries[i].section = "claims";
    }
  }
  detectWrapHyphens(entries);
  return entries;
}

// src/shared/matching.js
function normalizeText(text) {
  return text.normalize("NFC").replace(/[\u200B\u200C\u200D\uFEFF\u00AD\u200E\u200F\u2060\u2061\u2062\u2063\u2064]/g, "").replace(/[\u2018\u2019\u201A\u201B]/g, "'").replace(/[\u201C\u201D\u201E\u201F]/g, '"').replace(/[\u2013\u2014\u2015]/g, "-").replace(/\uFB01/g, "fi").replace(/\uFB02/g, "fl").replace(/\uFB00/g, "ff").replace(/\uFB03/g, "ffi").replace(/\uFB04/g, "ffl").replace(/\s+/g, " ").trim();
}
var OCR_PAIRS = [
  ["rn", "m"],
  ["cl", "d"],
  ["cI", "d"],
  ["vv", "w"],
  ["li", "h"]
];
function normalizeOcr(text) {
  let result = text;
  for (const [from, to] of OCR_PAIRS) {
    result = result.split(from).join(to);
  }
  return { text: result, changed: result !== text };
}
function buildConcat(positionMap) {
  let concat = "";
  const boundaries = [];
  const changedRanges = [];
  for (let i = 0; i < positionMap.length; i++) {
    const entry = positionMap[i];
    let lineText = normalizeText(entry.text);
    const prev = positionMap[i - 1];
    const prevIsWrapHyphen = prev && prev.column === entry.column && /^[a-z]/.test(lineText) && (prev.hasWrapHyphen || concat.endsWith("-") || /[-\u00AD\u2010\u2011\u2012]\s*$/.test(prev.text));
    if (prevIsWrapHyphen) {
      concat = concat.replace(/-$/, "");
    } else if (concat.length > 0) {
      concat += " ";
    }
    const { text: ocrText, changed } = normalizeOcr(lineText);
    lineText = ocrText;
    const charStart = concat.length;
    concat += lineText;
    boundaries.push({ charStart, charEnd: concat.length, entryIdx: i });
    if (changed) {
      changedRanges.push({ start: charStart, end: concat.length });
    }
  }
  return { concat, boundaries, changedRanges };
}
function findAllOccurrences(haystack, needle) {
  const positions = [];
  let idx = haystack.indexOf(needle);
  while (idx !== -1) {
    positions.push(idx);
    idx = haystack.indexOf(needle, idx + 1);
  }
  return positions;
}
function pickBestByContext(positions, matchLen, concat, contextBefore, contextAfter) {
  if (positions.length === 1) return positions[0];
  if (!contextBefore && !contextAfter) return positions[positions.length - 1];
  const normBefore = contextBefore ? normalizeText(contextBefore) : "";
  const normAfter = contextAfter ? normalizeText(contextAfter) : "";
  const toWords = (s) => s.toLowerCase().split(/\s+/).filter((w) => w.length > 0);
  const beforeWords = toWords(normBefore);
  const afterWords = toWords(normAfter);
  let bestPos = positions[0];
  let bestScore = -1;
  for (const pos of positions) {
    let score = 0;
    if (beforeWords.length > 0) {
      const before = concat.substring(Math.max(0, pos - normBefore.length - 50), pos);
      const concatWords = toWords(before);
      const minLen = Math.min(concatWords.length, beforeWords.length);
      for (let i = 1; i <= minLen; i++) {
        if (concatWords[concatWords.length - i] === beforeWords[beforeWords.length - i]) score++;
      }
    }
    if (afterWords.length > 0) {
      const after = concat.substring(pos + matchLen, pos + matchLen + normAfter.length + 50);
      const concatWords = toWords(after);
      const minLen = Math.min(concatWords.length, afterWords.length);
      for (let i = 0; i < minLen; i++) {
        if (concatWords[i] === afterWords[i]) score++;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestPos = pos;
    }
  }
  return bestPos;
}
function whitespaceStrippedMatch(normalized, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < 2) return null;
  const concatStripped = [];
  const strippedToOriginal = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStripped.push(concat[i]);
    }
  }
  const concatStrippedStr = concatStripped.join("");
  let allIdx = findAllOccurrences(concatStrippedStr, selStripped);
  let confidence = 0.99;
  if (allIdx.length === 0) {
    allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), selStripped.toLowerCase());
    confidence = 0.98;
  }
  if (allIdx.length === 0) {
    const trimmed = selStripped.replace(/^[.,;:!?]+/, "").replace(/[.,;:!?]+$/, "");
    if (trimmed.length >= 2 && trimmed !== selStripped) {
      allIdx = findAllOccurrences(concatStrippedStr, trimmed);
      confidence = 0.98;
      if (allIdx.length === 0) {
        allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), trimmed.toLowerCase());
        confidence = 0.97;
      }
    }
  }
  let idx = -1;
  if (allIdx.length > 0) {
    if (allIdx.length === 1) {
      idx = allIdx[0];
    } else {
      const origPositions = allIdx.map((si) => strippedToOriginal[si]);
      const origLen = strippedToOriginal[allIdx[0] + selStripped.length - 1] + 1 - strippedToOriginal[allIdx[0]];
      const bestOrig = pickBestByContext(origPositions, origLen, concat, contextBefore, contextAfter);
      idx = allIdx[origPositions.indexOf(bestOrig)];
    }
  }
  if (idx === -1) {
    const selAlpha = selStripped.replace(/[^a-zA-Z0-9]/g, "");
    const concatAlpha = concatStrippedStr.replace(/[^a-zA-Z0-9]/g, "");
    if (selAlpha.length >= 2) {
      let alphaIdx = concatAlpha.indexOf(selAlpha);
      if (alphaIdx === -1) {
        alphaIdx = concatAlpha.toLowerCase().indexOf(selAlpha.toLowerCase());
      }
      if (alphaIdx !== -1) {
        let alphaCount = 0;
        let mappedStart = -1;
        let mappedEnd = -1;
        for (let i = 0; i < concatStrippedStr.length; i++) {
          if (/[a-zA-Z0-9]/.test(concatStrippedStr[i])) {
            if (alphaCount === alphaIdx) mappedStart = i;
            if (alphaCount === alphaIdx + selAlpha.length - 1) {
              mappedEnd = i + 1;
              break;
            }
            alphaCount++;
          }
        }
        if (mappedStart !== -1 && mappedEnd !== -1) {
          idx = mappedStart;
          confidence = 0.96;
          const origStart2 = strippedToOriginal[mappedStart];
          const origEnd2 = strippedToOriginal[mappedEnd - 1] + 1;
          return resolveMatch(origStart2, origEnd2, boundaries, positionMap, confidence);
        }
      }
    }
  }
  if (idx === -1) return null;
  const origStart = strippedToOriginal[idx];
  const origEnd = strippedToOriginal[idx + selStripped.length - 1] + 1;
  return resolveMatch(origStart, origEnd, boundaries, positionMap, confidence);
}
function bookendMatch(normalized, concat, boundaries, positionMap) {
  const BOOKEND_LEN = 50;
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < BOOKEND_LEN * 2) return null;
  const prefix = selStripped.substring(0, BOOKEND_LEN);
  const suffix = selStripped.substring(selStripped.length - BOOKEND_LEN);
  const strippedToOriginal = [];
  const concatStrippedChars = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStrippedChars.push(concat[i]);
    }
  }
  const concatStripped = concatStrippedChars.join("");
  const concatStrippedLower = concatStripped.toLowerCase();
  const prefixLower = prefix.toLowerCase();
  const suffixLower = suffix.toLowerCase();
  const maxSpan = selStripped.length * 2;
  let searchFrom = 0;
  while (searchFrom < concatStripped.length) {
    let prefixIdx = concatStripped.indexOf(prefix, searchFrom);
    if (prefixIdx === -1) prefixIdx = concatStrippedLower.indexOf(prefixLower, searchFrom);
    if (prefixIdx === -1) break;
    const suffixSearchStart = prefixIdx + BOOKEND_LEN;
    let suffixIdx = concatStripped.indexOf(suffix, suffixSearchStart);
    if (suffixIdx === -1) suffixIdx = concatStrippedLower.indexOf(suffixLower, suffixSearchStart);
    if (suffixIdx !== -1) {
      const span = suffixIdx + BOOKEND_LEN - prefixIdx;
      if (span <= maxSpan) {
        const origStart = strippedToOriginal[prefixIdx];
        const origEnd = strippedToOriginal[suffixIdx + BOOKEND_LEN - 1] + 1;
        const startBoundary = boundaries.find((b) => b.charStart <= origStart && b.charEnd > origStart);
        const endBoundary = boundaries.find((b) => b.charStart < origEnd && b.charEnd >= origEnd);
        if (startBoundary && endBoundary && endBoundary.entryIdx - startBoundary.entryIdx <= 60) {
          return resolveMatch(origStart, origEnd, boundaries, positionMap, 0.92);
        }
      }
    }
    searchFrom = prefixIdx + 1;
  }
  return null;
}
function resolveMatch(matchStart, matchEnd, boundaries, positionMap, confidence) {
  const startBoundary = boundaries.find((b) => b.charStart <= matchStart && b.charEnd > matchStart);
  const endBoundary = boundaries.find((b) => b.charStart < matchEnd && b.charEnd >= matchEnd);
  if (!startBoundary || !endBoundary) return null;
  const startEntry = positionMap[startBoundary.entryIdx];
  const endEntry = positionMap[endBoundary.entryIdx];
  return {
    citation: formatCitation(startEntry, endEntry),
    startEntry,
    endEntry,
    confidence
  };
}
function formatCitation(startEntry, endEntry) {
  const startCol = startEntry.column;
  const startLine = startEntry.lineNumber;
  const endCol = endEntry.column;
  const endLine = endEntry.lineNumber;
  if (startCol === endCol && startLine === endLine) {
    return `${startCol}:${startLine}`;
  } else if (startCol === endCol) {
    return `${startCol}:${startLine}-${endLine}`;
  } else {
    return `${startCol}:${startLine}-${endCol}:${endLine}`;
  }
}
function fuzzySubstringMatch(needle, haystack) {
  const n = needle.length;
  if (n === 0 || n > 100) return null;
  const maxDistance = Math.floor(n * 0.2);
  let bestSimilarity = 0;
  let bestStart = -1;
  let bestEnd = -1;
  const windowMin = Math.max(1, n - maxDistance);
  const windowMax = n + maxDistance;
  for (let windowSize = windowMin; windowSize <= windowMax; windowSize++) {
    for (let start = 0; start <= haystack.length - windowSize; start++) {
      const candidate = haystack.substring(start, start + windowSize);
      const distance = levenshtein(needle, candidate);
      const similarity = 1 - distance / Math.max(n, windowSize);
      if (similarity > bestSimilarity) {
        bestSimilarity = similarity;
        bestStart = start;
        bestEnd = start + windowSize;
      }
    }
  }
  if (bestSimilarity >= 0.8) {
    return { start: bestStart, end: bestEnd, similarity: bestSimilarity };
  }
  return null;
}
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}
var GUTTER_VALUES = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65];
function stripGutterNumbers(concat) {
  const survive = new Uint8Array(concat.length).fill(1);
  for (const n of GUTTER_VALUES) {
    const numStr = String(n);
    const len = numStr.length;
    for (let pos = 0; pos <= concat.length - len; pos++) {
      if (concat.substring(pos, pos + len) === numStr) {
        const before = pos === 0 || concat[pos - 1] === " ";
        const after = pos + len === concat.length || concat[pos + len] === " ";
        if (before && after) {
          for (let k = pos; k < pos + len; k++) survive[k] = 0;
        }
      }
    }
  }
  const preCollapseToOrig = [];
  let preCollapse = "";
  for (let i = 0; i < concat.length; i++) {
    if (survive[i]) {
      preCollapseToOrig.push(i);
      preCollapse += concat[i];
    }
  }
  const strippedToOrig = [];
  let stripped = "";
  let prevWasSpace = false;
  for (let i = 0; i < preCollapse.length; i++) {
    const ch = preCollapse[i];
    if (ch === " ") {
      if (!prevWasSpace && stripped.length > 0) {
        strippedToOrig.push(preCollapseToOrig[i]);
        stripped += ch;
        prevWasSpace = true;
      }
    } else {
      strippedToOrig.push(preCollapseToOrig[i]);
      stripped += ch;
      prevWasSpace = false;
    }
  }
  if (stripped.endsWith(" ")) {
    stripped = stripped.slice(0, -1);
    strippedToOrig.pop();
  }
  const changed = stripped !== concat;
  return { stripped, strippedToOrig, changed };
}
function gutterTolerantMatch(selection, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const { stripped, strippedToOrig, changed } = stripGutterNumbers(concat);
  if (!changed) return null;
  const origToStripped = new Int32Array(concat.length).fill(-1);
  for (let si = 0; si < strippedToOrig.length; si++) {
    origToStripped[strippedToOrig[si]] = si;
  }
  const remappedBoundaries = boundaries.map((b) => {
    let newStart = origToStripped[b.charStart];
    if (newStart === -1) {
      for (let j = b.charStart; j < concat.length; j++) {
        if (origToStripped[j] !== -1) {
          newStart = origToStripped[j];
          break;
        }
      }
    }
    if (newStart === -1) newStart = 0;
    let newEnd = -1;
    for (let j = b.charEnd - 1; j >= b.charStart; j--) {
      if (origToStripped[j] !== -1) {
        newEnd = origToStripped[j] + 1;
        break;
      }
    }
    if (newEnd === -1) newEnd = newStart + 1;
    return { charStart: newStart, charEnd: newEnd, entryIdx: b.entryIdx };
  });
  const exactPositions = findAllOccurrences(stripped, selection);
  if (exactPositions.length > 0) {
    const bestPos = pickBestByContext(exactPositions, selection.length, stripped, contextBefore, contextAfter);
    const result = resolveMatch(bestPos, bestPos + selection.length, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  const wsResult = whitespaceStrippedMatch(selection, stripped, remappedBoundaries, positionMap, contextBefore, contextAfter);
  if (wsResult) return { ...wsResult, confidence: 0.85 };
  if (selection.length > 60) {
    const beResult = bookendMatch(selection, stripped, remappedBoundaries, positionMap);
    if (beResult) return { ...beResult, confidence: 0.85 };
  }
  const fuzzyResult = fuzzySubstringMatch(selection, stripped);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    const result = resolveMatch(fuzzyResult.start, fuzzyResult.end, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  return null;
}
function matchAndCite(selectedText, positionMap, contextBefore = "", contextAfter = "") {
  let normalized = normalizeText(selectedText);
  if (!normalized || normalized.length < 2) return null;
  if (!positionMap || positionMap.length === 0) return null;
  normalized = normalized.replace(/- ([a-z])/g, "$1");
  const { text: ocrNormalized, changed: selChanged } = normalizeOcr(normalized);
  const { concat, boundaries } = buildConcat(positionMap);
  function applyPenaltyIfNeeded(result) {
    if (!result || !selChanged) return result;
    return { ...result, confidence: result.confidence - 0.02 };
  }
  const allPositions = findAllOccurrences(concat, ocrNormalized);
  if (allPositions.length > 0) {
    const bestPos = pickBestByContext(allPositions, ocrNormalized.length, concat, contextBefore, contextAfter);
    const matchEnd = bestPos + ocrNormalized.length;
    return applyPenaltyIfNeeded(resolveMatch(bestPos, matchEnd, boundaries, positionMap, 1));
  }
  const strippedResult = whitespaceStrippedMatch(ocrNormalized, concat, boundaries, positionMap, contextBefore, contextAfter);
  if (strippedResult) return applyPenaltyIfNeeded(strippedResult);
  if (ocrNormalized.length > 60) {
    const bookendResult = bookendMatch(ocrNormalized, concat, boundaries, positionMap);
    if (bookendResult) return applyPenaltyIfNeeded(bookendResult);
  }
  const fuzzyResult = fuzzySubstringMatch(ocrNormalized, concat);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    return applyPenaltyIfNeeded(resolveMatch(
      fuzzyResult.start,
      fuzzyResult.end,
      boundaries,
      positionMap,
      fuzzyResult.similarity
    ));
  }
  const gutterResult = gutterTolerantMatch(
    ocrNormalized,
    concat,
    boundaries,
    positionMap,
    contextBefore,
    contextAfter
  );
  if (gutterResult) return gutterResult;
  return null;
}

// src/firefox/pdf-pipeline.js
var WORKER_URL = "https://pct.tonyrowles.com";
var PROXY_TOKEN = "4509b9943f831fb140eb0c3a7304f23cc6f72e41b5e5f8c800a42e94f09cadbe";
var CACHE_VERSION = "v5";
var idbAvailable = true;
var positionMapCache = /* @__PURE__ */ new Map();
function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("patent-cite-tool", 1);
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains("pdfs")) {
        db.createObjectStore("pdfs", { keyPath: "patentId" });
      }
    };
    request.onsuccess = (event) => {
      resolve(event.target.result);
    };
    request.onerror = (event) => {
      reject(new Error(`IndexedDB open failed: ${event.target.error}`));
    };
  });
}
function degradeIdb(err) {
  idbAvailable = false;
  console.warn("[Firefox] IndexedDB unavailable, using in-memory cache:", err.message);
}
async function storePositionMap(patentId, positionMap, positionMapMeta, pdfBlob = null, timestamp = null) {
  positionMapCache.set(patentId, { positionMap, positionMapMeta });
  if (!idbAvailable) return;
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readwrite");
      const store = tx.objectStore("pdfs");
      store.put({
        patentId,
        pdf: pdfBlob,
        timestamp: timestamp ?? Date.now(),
        positionMap,
        positionMapMeta
      });
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = (event) => {
        db.close();
        const err = event.target.error;
        if (err && (err.name === "InvalidStateError" || err.name === "UnknownError")) {
          degradeIdb(err);
          resolve();
        } else {
          reject(new Error(`IndexedDB write failed: ${err}`));
        }
      };
    });
  } catch (err) {
    if (err.name === "InvalidStateError" || err.name === "UnknownError") {
      degradeIdb(err);
    } else {
      console.warn("[Firefox] IDB storePositionMap error:", err.message);
    }
  }
}
async function readPositionMap(patentId) {
  if (positionMapCache.has(patentId)) {
    return positionMapCache.get(patentId);
  }
  if (!idbAvailable) return null;
  try {
    const db = await openDb();
    const record = await new Promise((resolve, reject) => {
      const tx = db.transaction("pdfs", "readonly");
      const store = tx.objectStore("pdfs");
      const request = store.get(patentId);
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(new Error(`IndexedDB read: ${event.target.error}`));
      tx.oncomplete = () => db.close();
    });
    if (!record || !record.positionMap || record.positionMap.length === 0) {
      return null;
    }
    const entry = {
      positionMap: record.positionMap,
      positionMapMeta: record.positionMapMeta
    };
    positionMapCache.set(patentId, entry);
    return entry;
  } catch (err) {
    console.warn("[Firefox] IDB readPositionMap error:", err.message);
    return null;
  }
}
async function checkCache(patentId) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 3e3);
  try {
    const url = `${WORKER_URL}/cache?patent=${encodeURIComponent(patentId)}&v=${CACHE_VERSION}`;
    const response = await fetch(url, {
      headers: { "Authorization": `Bearer ${PROXY_TOKEN}` },
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!response.ok) return null;
    return await response.json();
  } catch (err) {
    clearTimeout(timeoutId);
    console.warn("[Firefox] Cache check failed:", err.message);
    return null;
  }
}
async function checkServerCache(patentId, pdfUrl) {
  console.log(`[Firefox] Checking cache for ${patentId}`);
  const cached = await checkCache(patentId);
  if (cached && cached.entries && cached.meta) {
    console.log(`[Firefox] Cache HIT for ${patentId} \u2014 ${cached.entries.length} entries`);
    await storePositionMap(
      patentId,
      cached.entries,
      cached.meta
    );
    return {
      hit: true,
      lineCount: cached.meta.totalLines,
      columnCount: cached.meta.totalColumns
    };
  }
  console.log(`[Firefox] Cache MISS for ${patentId}`);
  return { hit: false, pdfUrl };
}
async function fetchAndParsePdf(patentId, pdfUrl) {
  let blob;
  try {
    blob = await fetchWithRetry(pdfUrl, {});
  } catch (err) {
    return { success: false, error: err.message };
  }
  if (idbAvailable) {
    try {
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const tx = db.transaction("pdfs", "readwrite");
        const store = tx.objectStore("pdfs");
        store.put({ patentId, pdf: blob, timestamp: Date.now() });
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = (event) => {
          db.close();
          const err = event.target.error;
          if (err && (err.name === "InvalidStateError" || err.name === "UnknownError")) {
            degradeIdb(err);
            resolve();
          } else {
            reject(new Error(`IndexedDB blob write failed: ${err}`));
          }
        };
      });
    } catch (err) {
      if (err.name === "InvalidStateError" || err.name === "UnknownError") {
        degradeIdb(err);
      } else {
        console.warn("[Firefox] PDF blob IDB write error:", err.message);
      }
    }
  }
  return await parsePdfBlob(patentId, blob);
}
async function fetchUsptoAndParse(patentId) {
  const workerUrl = `${WORKER_URL}?patent=${encodeURIComponent(patentId)}`;
  let blob;
  try {
    blob = await fetchWithRetry(workerUrl, {
      headers: { "Authorization": `Bearer ${PROXY_TOKEN}` }
    });
  } catch (err) {
    return { success: false, error: err.message };
  }
  if (idbAvailable) {
    try {
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const tx = db.transaction("pdfs", "readwrite");
        const store = tx.objectStore("pdfs");
        store.put({ patentId, pdf: blob, timestamp: Date.now() });
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = (event) => {
          db.close();
          const err = event.target.error;
          if (err && (err.name === "InvalidStateError" || err.name === "UnknownError")) {
            degradeIdb(err);
            resolve();
          } else {
            reject(new Error(`IndexedDB blob write failed: ${err}`));
          }
        };
      });
    } catch (err) {
      if (err.name === "InvalidStateError" || err.name === "UnknownError") {
        degradeIdb(err);
      } else {
        console.warn("[Firefox] USPTO PDF blob IDB write error:", err.message);
      }
    }
  }
  return await parsePdfBlob(patentId, blob);
}
async function lookupPosition(selectedText, patentId, contextBefore = "", contextAfter = "") {
  try {
    const entry = await readPositionMap(patentId);
    if (!entry || !entry.positionMap || entry.positionMap.length === 0) {
      return null;
    }
    const result = matchAndCite(selectedText, entry.positionMap, contextBefore, contextAfter);
    return result || null;
  } catch (error) {
    console.error("[Firefox] Lookup error:", error);
    return null;
  }
}
async function uploadToCache(patentId) {
  try {
    const entry = await readPositionMap(patentId);
    if (!entry?.positionMap || !entry?.positionMapMeta) {
      console.warn("[Firefox] No positionMap to upload for", patentId);
      return;
    }
    const entries = entry.positionMap.map(({ text, column, lineNumber, page, section, hasWrapHyphen }) => ({
      text,
      column,
      lineNumber,
      page,
      section,
      hasWrapHyphen
    }));
    const payload = {
      entries,
      meta: {
        totalLines: entry.positionMapMeta.totalLines,
        totalColumns: entry.positionMapMeta.totalColumns,
        hasClaimsSection: entry.positionMapMeta.hasClaimsSection
      },
      cachedAt: Date.now(),
      version: CACHE_VERSION
    };
    const url = `${WORKER_URL}/cache?patent=${encodeURIComponent(patentId)}&v=${CACHE_VERSION}`;
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${PROXY_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    console.log(`[Firefox] Cache upload for ${patentId}: ${resp.status} ${resp.statusText}`);
  } catch (err) {
    console.warn("[Firefox] Cache upload failed:", err.message);
  }
}
async function fetchWithRetry(url, fetchOptions, retries = 1) {
  try {
    const response = await fetch(url, fetchOptions);
    if (!response.ok) {
      const errorText = await response.text().catch(() => `HTTP ${response.status}`);
      throw new Error(errorText);
    }
    return await response.blob();
  } catch (err) {
    if (retries > 0) {
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      return fetchWithRetry(url, fetchOptions, retries - 1);
    }
    throw err;
  }
}
async function parsePdfBlob(patentId, blob) {
  try {
    const arrayBuffer = await blob.arrayBuffer();
    const pageResults = await extractTextFromPdf(arrayBuffer);
    const positionMap = buildPositionMap(pageResults);
    if (positionMap.length === 0) {
      const totalItems = pageResults.reduce((sum, p) => sum + p.items.length, 0);
      if (totalItems > 0) {
        console.warn(`[Firefox] Patent has ${totalItems} text items but no two-column pages detected`);
      }
    }
    const positionMapMeta = {
      totalLines: positionMap.length,
      totalColumns: positionMap.length > 0 ? positionMap[positionMap.length - 1].column : 0,
      hasClaimsSection: positionMap.some((e) => e.section === "claims"),
      builtAt: Date.now()
    };
    await storePositionMap(patentId, positionMap, positionMapMeta);
    return {
      success: true,
      lineCount: positionMap.length,
      columnCount: positionMapMeta.totalColumns
    };
  } catch (error) {
    if (error.message === "NO_TEXT_LAYER") {
      return { success: false, error: "no-text-layer" };
    }
    console.error(`[Firefox] PDF parse error for ${patentId}:`, error);
    return { success: false, error: error.message };
  }
}

// src/shared/report-transport.js
var PROXY_TOKEN2 = "4509b9943f831fb140eb0c3a7304f23cc6f72e41b5e5f8c800a42e94f09cadbe";
var BACKOFF_MS = [2e3, 8e3, 3e4];
var MAX_ATTEMPTS = 3;
var RATE_LIMIT_MAX = 5;
var RATE_LIMIT_WINDOW_MS = 6e5;
var QUEUE_KEY = "bugReportQueue";
var RATE_KEY = "bugReportRateLimitWindow";
var QUEUE_CAP = 20;
var QUEUE_TTL_MS = 6048e5;
var drainingQueue = null;
var storageLock = Promise.resolve();
function withStorageLock(fn) {
  const run = storageLock.then(fn, fn);
  storageLock = run.then(() => {
  }, () => {
  });
  return run;
}
async function checkAndUpdateRateLimit() {
  return withStorageLock(async () => {
    const now = Date.now();
    const stored = await chrome.storage.local.get(RATE_KEY);
    const raw = stored[RATE_KEY];
    const window2 = (Array.isArray(raw) ? raw : []).filter((ts) => now - ts < RATE_LIMIT_WINDOW_MS);
    if (window2.length >= RATE_LIMIT_MAX) {
      return false;
    }
    window2.push(now);
    await chrome.storage.local.set({ [RATE_KEY]: window2 });
    return true;
  });
}
async function submitReport(payload) {
  if (payload == null) {
    return { ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true };
  }
  const allowed = await checkAndUpdateRateLimit();
  if (!allowed) {
    return { ok: false, queued: false, fingerprint: null, rateLimited: true, dropped: false };
  }
  const entry = {
    payload,
    attemptCount: 0,
    nextAttemptAt: 0,
    // 0 = immediately eligible for drain
    enqueuedAt: Date.now()
  };
  await _enqueueEntry(entry);
  const result = await attemptEntry(entry);
  if (result.outcome === "success") {
    return { ok: true, queued: false, fingerprint: result.fingerprint, rateLimited: false, dropped: false };
  } else if (result.outcome === "queued") {
    return { ok: false, queued: true, fingerprint: null, rateLimited: false, dropped: false };
  } else {
    return { ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true };
  }
}
async function attemptEntry(entry) {
  let resp;
  let networkError = false;
  try {
    resp = await fetch(WORKER_REPORT_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${PROXY_TOKEN2}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(entry.payload)
    });
  } catch {
    networkError = true;
  }
  if (!networkError && resp.ok) {
    let fingerprint = null;
    try {
      const body = await resp.json();
      fingerprint = body.fingerprint ?? null;
    } catch {
    }
    await _removeEntryFromQueue(entry);
    return { outcome: "success", fingerprint };
  }
  if (!networkError && resp.status >= 400 && resp.status < 500 && resp.status !== 429) {
    await _removeEntryFromQueue(entry);
    return { outcome: "dropped" };
  }
  entry.attemptCount += 1;
  const backoffMs = BACKOFF_MS[entry.attemptCount - 1] ?? BACKOFF_MS[BACKOFF_MS.length - 1];
  entry.nextAttemptAt = Date.now() + backoffMs;
  if (entry.attemptCount >= MAX_ATTEMPTS) {
    await _removeEntryFromQueue(entry);
    return { outcome: "dropped" };
  }
  await _updateEntryInQueue(entry);
  setTimeout(() => {
    drainQueueOnce().catch(() => {
    });
  }, backoffMs);
  return { outcome: "queued" };
}
async function _enqueueEntry(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const now = Date.now();
    let queue = (Array.isArray(raw) ? raw : []).filter((e) => now - e.enqueuedAt < QUEUE_TTL_MS);
    queue.push(entry);
    if (queue.length > QUEUE_CAP) {
      queue.sort((a, b) => a.enqueuedAt - b.enqueuedAt);
      queue = queue.slice(queue.length - QUEUE_CAP);
    }
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function _removeEntryFromQueue(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const queue = (Array.isArray(raw) ? raw : []).filter((e) => e.enqueuedAt !== entry.enqueuedAt);
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function _updateEntryInQueue(entry) {
  return withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    const queue = (Array.isArray(raw) ? raw : []).map(
      (e) => e.enqueuedAt === entry.enqueuedAt ? entry : e
    );
    await chrome.storage.local.set({ [QUEUE_KEY]: queue });
  });
}
async function drainQueueOnce() {
  if (drainingQueue) {
    return drainingQueue;
  }
  drainingQueue = _doDrain();
  try {
    await drainingQueue;
  } finally {
    drainingQueue = null;
  }
}
async function _doDrain() {
  const eligible = await withStorageLock(async () => {
    const stored = await chrome.storage.local.get(QUEUE_KEY);
    const raw = stored[QUEUE_KEY];
    if (!Array.isArray(raw) || raw.length === 0) return [];
    const now = Date.now();
    const live = raw.filter((e) => now - e.enqueuedAt < QUEUE_TTL_MS);
    if (live.length !== raw.length) {
      await chrome.storage.local.set({ [QUEUE_KEY]: live });
    }
    return live.filter((e) => e.nextAttemptAt <= now);
  });
  for (const entry of eligible) {
    await attemptEntry(entry);
  }
}

// src/content/report-dialog.js
var ERROR_BUFFER_KEY = "bugReportErrorBuffer";
var BUFFER_MAX = 20;
var EXTENSION_PREFIXES = ["[SW]", "[PCT]", "[Offscreen]", "[Firefox]", "[BG]"];
var _bufferInstalled = false;
function isExtensionTagged(args) {
  const first = args[0];
  if (typeof first !== "string") return false;
  return EXTENSION_PREFIXES.some((p) => first.startsWith(p));
}
async function appendToBuffer(level, args) {
  try {
    const message = args.map((a) => typeof a === "string" ? a : JSON.stringify(a)).join(" ").substring(0, 500);
    const entry = { level, message, ts: Date.now() };
    const stored = await chrome.storage.local.get(ERROR_BUFFER_KEY);
    const buf = Array.isArray(stored[ERROR_BUFFER_KEY]) ? stored[ERROR_BUFFER_KEY] : [];
    buf.push(entry);
    const trimmed = buf.length > BUFFER_MAX ? buf.slice(buf.length - BUFFER_MAX) : buf;
    await chrome.storage.local.set({ [ERROR_BUFFER_KEY]: trimmed });
  } catch {
  }
}
function installErrorBuffer() {
  if (_bufferInstalled) return;
  _bufferInstalled = true;
  const origError = console.error.bind(console);
  const origWarn = console.warn.bind(console);
  console.error = function(...args) {
    origError(...args);
    if (isExtensionTagged(args)) appendToBuffer("error", args).catch(() => {
    });
  };
  console.warn = function(...args) {
    origWarn(...args);
    if (isExtensionTagged(args)) appendToBuffer("warn", args).catch(() => {
    });
  };
}

// src/firefox/background.js
installErrorBuffer();
var ICON_PATHS = {
  partial: {
    16: "/icons/icon-partial-16.png",
    32: "/icons/icon-partial-32.png",
    48: "/icons/icon-partial-48.png",
    128: "/icons/icon-partial-128.png"
  },
  active: {
    16: "/icons/icon-active-16.png",
    32: "/icons/icon-active-32.png",
    48: "/icons/icon-active-48.png",
    128: "/icons/icon-active-128.png"
  }
};
function setTabIcon(tabId, state) {
  if (!tabId) return;
  chrome.action.setIcon({ path: ICON_PATHS[state], tabId });
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.action.disable();
  chrome.contextMenus.create({
    id: "get-patent-citation",
    title: "Get Citation",
    contexts: ["selection"],
    documentUrlPatterns: ["https://patents.google.com/patent/US*"]
  });
  drainQueueOnce().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  drainQueueOnce().catch(() => {
  });
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!changeInfo.url) return;
  if (changeInfo.url.startsWith("https://patents.google.com/patent/US")) {
    chrome.action.enable(tabId);
  } else {
    chrome.action.disable(tabId);
  }
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "get-patent-citation" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: MSG.GENERATE_CITATION,
      selectedText: info.selectionText
    }).catch((err) => console.warn("[BG] Context menu send failed:", err.message));
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  drainQueueOnce().catch(() => {
  });
  const tabId = sender.tab?.id;
  if (message.type === MSG.PDF_LINK_FOUND) {
    handlePdfLinkFound(message, tabId);
  } else if (message.type === MSG.PDF_LINK_NOT_FOUND) {
    handlePdfUnavailable(message, tabId);
  } else if (message.type === MSG.LOOKUP_POSITION) {
    handleLookupPosition(message, sender);
  } else if (message.type === MSG.GET_STATUS) {
    handleGetStatus(sendResponse);
    return true;
  } else if (message.type === MSG.SUBMIT_REPORT) {
    submitReport(message.payload).then((result) => sendResponse(result)).catch(() => sendResponse({ ok: false, queued: false, fingerprint: null, rateLimited: false, dropped: true }));
    return true;
  }
});
async function handlePdfLinkFound(message, tabId) {
  const { patentId, patentType, kindCode, pdfUrl } = message;
  await chrome.storage.local.set({
    currentPatent: {
      patentId,
      patentType,
      kindCode,
      pdfUrl,
      tabId,
      status: STATUS.FETCHING,
      source: "google",
      error: null
    }
  });
  setTabIcon(tabId, "partial");
  const cacheResult = await checkServerCache(patentId, pdfUrl);
  if (cacheResult.hit) {
    console.log(`[BG] Cache HIT for ${patentId} \u2014 skipping PDF fetch/parse`);
    const data = await chrome.storage.local.get("currentPatent");
    const patent = data.currentPatent;
    if (!patent) return;
    patent.status = STATUS.PARSED;
    patent.source = null;
    patent.lineCount = cacheResult.lineCount;
    patent.columnCount = cacheResult.columnCount;
    patent.error = null;
    chrome.action.setBadgeText({ text: "" });
    setTabIcon(patent.tabId, "active");
    await chrome.storage.local.set({ currentPatent: patent });
    return;
  }
  await fetchAndProcessPdf(patentId, patentType, pdfUrl, tabId, false);
}
async function handlePdfUnavailable(message, tabId) {
  const { patentId, patentType, kindCode } = message;
  if (patentType === PATENT_TYPE.GRANT) {
    console.log(`[BG] No Google PDF for ${patentId}, checking cache before USPTO fallback`);
    await chrome.storage.local.set({
      currentPatent: {
        patentId,
        patentType,
        kindCode,
        pdfUrl: null,
        tabId,
        status: STATUS.FETCHING,
        source: null,
        error: null
      }
    });
    setTabIcon(tabId, "partial");
    const cacheResult = await checkServerCache(patentId, null);
    if (cacheResult.hit) {
      console.log(`[BG] Cache HIT for ${patentId} \u2014 skipping USPTO fetch`);
      const data = await chrome.storage.local.get("currentPatent");
      const patent = data.currentPatent;
      if (!patent) return;
      patent.status = STATUS.PARSED;
      patent.lineCount = cacheResult.lineCount;
      patent.columnCount = cacheResult.columnCount;
      patent.error = null;
      chrome.action.setBadgeText({ text: "" });
      setTabIcon(patent.tabId, "active");
      await chrome.storage.local.set({ currentPatent: patent });
      return;
    }
    await fetchAndProcessPdf(patentId, patentType, null, tabId, false);
  } else {
    await chrome.storage.local.set({
      currentPatent: {
        patentId,
        patentType,
        kindCode,
        pdfUrl: null,
        tabId,
        status: STATUS.UNAVAILABLE,
        error: null
      }
    });
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
  }
}
async function handleLookupPosition(message, sender) {
  const tabId = sender.tab?.id;
  if (!tabId) return;
  try {
    const result = await lookupPosition(
      message.selectedText,
      message.patentId,
      message.contextBefore || "",
      message.contextAfter || ""
    );
    if (result) {
      chrome.tabs.sendMessage(tabId, {
        type: MSG.CITATION_RESULT,
        success: true,
        citation: result.citation,
        confidence: result.confidence,
        startEntry: {
          column: result.startEntry.column,
          lineNumber: result.startEntry.lineNumber,
          page: result.startEntry.page,
          section: result.startEntry.section
        },
        endEntry: {
          column: result.endEntry.column,
          lineNumber: result.endEntry.lineNumber,
          page: result.endEntry.page,
          section: result.endEntry.section
        }
      }).catch(() => {
      });
    } else {
      chrome.tabs.sendMessage(tabId, {
        type: MSG.CITATION_RESULT,
        success: false,
        error: "no-match"
      }).catch(() => {
      });
    }
  } catch (error) {
    console.warn("[BG] Lookup failed:", error.message);
    chrome.tabs.sendMessage(tabId, {
      type: MSG.CITATION_RESULT,
      success: false,
      error: "lookup-failed"
    }).catch(() => {
    });
  }
}
async function handleGetStatus(sendResponse) {
  const data = await chrome.storage.local.get("currentPatent");
  sendResponse(data.currentPatent || null);
}
async function fetchAndProcessPdf(patentId, patentType, pdfUrl, tabId, usptoAttempted) {
  let result;
  let source;
  if (pdfUrl) {
    console.log(`[BG] Fetching Google PDF for ${patentId}`);
    result = await fetchAndParsePdf(patentId, pdfUrl);
    source = "google";
  } else {
    console.log(`[BG] No Google PDF, trying USPTO for ${patentId}`);
    result = await fetchUsptoAndParse(patentId);
    source = "uspto";
    usptoAttempted = true;
  }
  if (result.success) {
    await handleParseSuccess(patentId, result.lineCount, result.columnCount, tabId);
    uploadToCache(patentId).catch(() => {
    });
    return;
  }
  if (result.error === "no-text-layer") {
    if (patentType === PATENT_TYPE.GRANT && !usptoAttempted) {
      console.log(`[BG] Google PDF has no text layer, trying USPTO for ${patentId}`);
      await updateStorage(patentId, { status: STATUS.FETCHING, source: null, error: null });
      const usptoResult = await fetchUsptoAndParse(patentId);
      if (usptoResult.success) {
        await handleParseSuccess(patentId, usptoResult.lineCount, usptoResult.columnCount, tabId);
        uploadToCache(patentId).catch(() => {
        });
      } else {
        await handleParseFailure(patentId, patentType, usptoResult.error, tabId, true);
      }
    } else {
      const data = await chrome.storage.local.get("currentPatent");
      const patent = data.currentPatent;
      if (!patent) return;
      patent.status = STATUS.NO_TEXT_LAYER;
      patent.error = null;
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
      await chrome.storage.local.set({ currentPatent: patent });
    }
    return;
  }
  if (patentType === PATENT_TYPE.GRANT && source === "google" && !usptoAttempted) {
    console.log(`[BG] Google PDF fetch failed, trying USPTO for ${patentId}`);
    await updateStorage(patentId, { status: STATUS.FETCHING, source: null, error: null });
    const usptoResult = await fetchUsptoAndParse(patentId);
    if (usptoResult.success) {
      await handleParseSuccess(patentId, usptoResult.lineCount, usptoResult.columnCount, tabId);
      uploadToCache(patentId).catch(() => {
      });
    } else {
      await handleParseFailure(patentId, patentType, usptoResult.error, tabId, true);
    }
  } else {
    await handleParseFailure(patentId, patentType, result.error, tabId, usptoAttempted);
  }
}
async function updateStorage(patentId, updates) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  Object.assign(patent, updates);
  await chrome.storage.local.set({ currentPatent: patent });
}
async function handleParseSuccess(patentId, lineCount, columnCount, tabId) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  patent.status = STATUS.PARSED;
  patent.lineCount = lineCount;
  patent.columnCount = columnCount;
  patent.error = null;
  chrome.action.setBadgeText({ text: "" });
  setTabIcon(patent.tabId, "active");
  await chrome.storage.local.set({ currentPatent: patent });
}
async function handleParseFailure(patentId, patentType, error, tabId, usptoAttempted) {
  const data = await chrome.storage.local.get("currentPatent");
  const patent = data.currentPatent;
  if (!patent) return;
  if (error === "no-text-layer" && usptoAttempted) {
    patent.status = STATUS.NO_TEXT_LAYER;
    patent.error = null;
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
  } else if (usptoAttempted) {
    patent.status = STATUS.UNAVAILABLE;
    patent.error = null;
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#F59E0B" });
  } else {
    patent.status = STATUS.ERROR;
    patent.error = error;
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#EF4444" });
  }
  await chrome.storage.local.set({ currentPatent: patent });
}
