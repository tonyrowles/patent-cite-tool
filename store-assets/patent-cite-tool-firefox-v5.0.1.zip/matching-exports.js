// src/shared/matching.js
function normalizeText(text) {
  return text.normalize("NFC").replace(/[\u200B\u200C\u200D\uFEFF\u00AD\u200E\u200F\u2060\u2061\u2062\u2063\u2064]/g, "").replace(/[\u2018\u2019\u201A\u201B]/g, "'").replace(/[\u201C\u201D\u201E\u201F]/g, '"').replace(/[\u2013\u2014\u2015]/g, "-").replace(/\uFB01/g, "fi").replace(/\uFB02/g, "fl").replace(/\uFB00/g, "ff").replace(/\uFB03/g, "ffi").replace(/\uFB04/g, "ffl").replace(/\s+/g, " ").trim();
}
var OCR_PAIRS = [
  ["rn", "m"],
  ["cl", "d"],
  ["cI", "d"],
  ["vv", "w"],
  ["li", "h"]
];
function normalizeOcr(text) {
  let result = text;
  for (const [from, to] of OCR_PAIRS) {
    result = result.split(from).join(to);
  }
  return { text: result, changed: result !== text };
}
function buildConcat(positionMap) {
  let concat = "";
  const boundaries = [];
  const changedRanges = [];
  for (let i = 0; i < positionMap.length; i++) {
    const entry = positionMap[i];
    let lineText = normalizeText(entry.text);
    const prev = positionMap[i - 1];
    const prevIsWrapHyphen = prev && prev.column === entry.column && /^[a-z]/.test(lineText) && (prev.hasWrapHyphen || concat.endsWith("-") || /[-\u00AD\u2010\u2011\u2012]\s*$/.test(prev.text));
    if (prevIsWrapHyphen) {
      concat = concat.replace(/-$/, "");
    } else if (concat.length > 0) {
      concat += " ";
    }
    const { text: ocrText, changed } = normalizeOcr(lineText);
    lineText = ocrText;
    const charStart = concat.length;
    concat += lineText;
    boundaries.push({ charStart, charEnd: concat.length, entryIdx: i });
    if (changed) {
      changedRanges.push({ start: charStart, end: concat.length });
    }
  }
  return { concat, boundaries, changedRanges };
}
function findAllOccurrences(haystack, needle) {
  const positions = [];
  let idx = haystack.indexOf(needle);
  while (idx !== -1) {
    positions.push(idx);
    idx = haystack.indexOf(needle, idx + 1);
  }
  return positions;
}
function pickBestByContext(positions, matchLen, concat, contextBefore, contextAfter) {
  if (positions.length === 1) return positions[0];
  if (!contextBefore && !contextAfter) return positions[positions.length - 1];
  const normBefore = contextBefore ? normalizeText(contextBefore) : "";
  const normAfter = contextAfter ? normalizeText(contextAfter) : "";
  const toWords = (s) => s.toLowerCase().split(/\s+/).filter((w) => w.length > 0);
  const beforeWords = toWords(normBefore);
  const afterWords = toWords(normAfter);
  let bestPos = positions[0];
  let bestScore = -1;
  for (const pos of positions) {
    let score = 0;
    if (beforeWords.length > 0) {
      const before = concat.substring(Math.max(0, pos - normBefore.length - 50), pos);
      const concatWords = toWords(before);
      const minLen = Math.min(concatWords.length, beforeWords.length);
      for (let i = 1; i <= minLen; i++) {
        if (concatWords[concatWords.length - i] === beforeWords[beforeWords.length - i]) score++;
      }
    }
    if (afterWords.length > 0) {
      const after = concat.substring(pos + matchLen, pos + matchLen + normAfter.length + 50);
      const concatWords = toWords(after);
      const minLen = Math.min(concatWords.length, afterWords.length);
      for (let i = 0; i < minLen; i++) {
        if (concatWords[i] === afterWords[i]) score++;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestPos = pos;
    }
  }
  return bestPos;
}
function whitespaceStrippedMatch(normalized, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < 2) return null;
  const concatStripped = [];
  const strippedToOriginal = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStripped.push(concat[i]);
    }
  }
  const concatStrippedStr = concatStripped.join("");
  let allIdx = findAllOccurrences(concatStrippedStr, selStripped);
  let confidence = 0.99;
  if (allIdx.length === 0) {
    allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), selStripped.toLowerCase());
    confidence = 0.98;
  }
  if (allIdx.length === 0) {
    const trimmed = selStripped.replace(/^[.,;:!?]+/, "").replace(/[.,;:!?]+$/, "");
    if (trimmed.length >= 2 && trimmed !== selStripped) {
      allIdx = findAllOccurrences(concatStrippedStr, trimmed);
      confidence = 0.98;
      if (allIdx.length === 0) {
        allIdx = findAllOccurrences(concatStrippedStr.toLowerCase(), trimmed.toLowerCase());
        confidence = 0.97;
      }
    }
  }
  let idx = -1;
  if (allIdx.length > 0) {
    if (allIdx.length === 1) {
      idx = allIdx[0];
    } else {
      const origPositions = allIdx.map((si) => strippedToOriginal[si]);
      const origLen = strippedToOriginal[allIdx[0] + selStripped.length - 1] + 1 - strippedToOriginal[allIdx[0]];
      const bestOrig = pickBestByContext(origPositions, origLen, concat, contextBefore, contextAfter);
      idx = allIdx[origPositions.indexOf(bestOrig)];
    }
  }
  if (idx === -1) {
    const selAlpha = selStripped.replace(/[^a-zA-Z0-9]/g, "");
    const concatAlpha = concatStrippedStr.replace(/[^a-zA-Z0-9]/g, "");
    if (selAlpha.length >= 2) {
      let alphaIdx = concatAlpha.indexOf(selAlpha);
      if (alphaIdx === -1) {
        alphaIdx = concatAlpha.toLowerCase().indexOf(selAlpha.toLowerCase());
      }
      if (alphaIdx !== -1) {
        let alphaCount = 0;
        let mappedStart = -1;
        let mappedEnd = -1;
        for (let i = 0; i < concatStrippedStr.length; i++) {
          if (/[a-zA-Z0-9]/.test(concatStrippedStr[i])) {
            if (alphaCount === alphaIdx) mappedStart = i;
            if (alphaCount === alphaIdx + selAlpha.length - 1) {
              mappedEnd = i + 1;
              break;
            }
            alphaCount++;
          }
        }
        if (mappedStart !== -1 && mappedEnd !== -1) {
          idx = mappedStart;
          confidence = 0.96;
          const origStart2 = strippedToOriginal[mappedStart];
          const origEnd2 = strippedToOriginal[mappedEnd - 1] + 1;
          return resolveMatch(origStart2, origEnd2, boundaries, positionMap, confidence);
        }
      }
    }
  }
  if (idx === -1) return null;
  const origStart = strippedToOriginal[idx];
  const origEnd = strippedToOriginal[idx + selStripped.length - 1] + 1;
  return resolveMatch(origStart, origEnd, boundaries, positionMap, confidence);
}
function bookendMatch(normalized, concat, boundaries, positionMap) {
  const BOOKEND_LEN = 50;
  const selStripped = normalized.replace(/\s/g, "");
  if (selStripped.length < BOOKEND_LEN * 2) return null;
  const prefix = selStripped.substring(0, BOOKEND_LEN);
  const suffix = selStripped.substring(selStripped.length - BOOKEND_LEN);
  const strippedToOriginal = [];
  const concatStrippedChars = [];
  for (let i = 0; i < concat.length; i++) {
    if (!/\s/.test(concat[i])) {
      strippedToOriginal.push(i);
      concatStrippedChars.push(concat[i]);
    }
  }
  const concatStripped = concatStrippedChars.join("");
  const concatStrippedLower = concatStripped.toLowerCase();
  const prefixLower = prefix.toLowerCase();
  const suffixLower = suffix.toLowerCase();
  const maxSpan = selStripped.length * 2;
  let searchFrom = 0;
  while (searchFrom < concatStripped.length) {
    let prefixIdx = concatStripped.indexOf(prefix, searchFrom);
    if (prefixIdx === -1) prefixIdx = concatStrippedLower.indexOf(prefixLower, searchFrom);
    if (prefixIdx === -1) break;
    const suffixSearchStart = prefixIdx + BOOKEND_LEN;
    let suffixIdx = concatStripped.indexOf(suffix, suffixSearchStart);
    if (suffixIdx === -1) suffixIdx = concatStrippedLower.indexOf(suffixLower, suffixSearchStart);
    if (suffixIdx !== -1) {
      const span = suffixIdx + BOOKEND_LEN - prefixIdx;
      if (span <= maxSpan) {
        const origStart = strippedToOriginal[prefixIdx];
        const origEnd = strippedToOriginal[suffixIdx + BOOKEND_LEN - 1] + 1;
        const startBoundary = boundaries.find((b) => b.charStart <= origStart && b.charEnd > origStart);
        const endBoundary = boundaries.find((b) => b.charStart < origEnd && b.charEnd >= origEnd);
        if (startBoundary && endBoundary && endBoundary.entryIdx - startBoundary.entryIdx <= 60) {
          return resolveMatch(origStart, origEnd, boundaries, positionMap, 0.92);
        }
      }
    }
    searchFrom = prefixIdx + 1;
  }
  return null;
}
function resolveMatch(matchStart, matchEnd, boundaries, positionMap, confidence) {
  const startBoundary = boundaries.find((b) => b.charStart <= matchStart && b.charEnd > matchStart);
  const endBoundary = boundaries.find((b) => b.charStart < matchEnd && b.charEnd >= matchEnd);
  if (!startBoundary || !endBoundary) return null;
  const startEntry = positionMap[startBoundary.entryIdx];
  const endEntry = positionMap[endBoundary.entryIdx];
  return {
    citation: formatCitation(startEntry, endEntry),
    startEntry,
    endEntry,
    confidence
  };
}
function formatCitation(startEntry, endEntry) {
  const startCol = startEntry.column;
  const startLine = startEntry.lineNumber;
  const endCol = endEntry.column;
  const endLine = endEntry.lineNumber;
  if (startCol === endCol && startLine === endLine) {
    return `${startCol}:${startLine}`;
  } else if (startCol === endCol) {
    return `${startCol}:${startLine}-${endLine}`;
  } else {
    return `${startCol}:${startLine}-${endCol}:${endLine}`;
  }
}
function fuzzySubstringMatch(needle, haystack) {
  const n = needle.length;
  if (n === 0 || n > 100) return null;
  const maxDistance = Math.floor(n * 0.2);
  let bestSimilarity = 0;
  let bestStart = -1;
  let bestEnd = -1;
  const windowMin = Math.max(1, n - maxDistance);
  const windowMax = n + maxDistance;
  for (let windowSize = windowMin; windowSize <= windowMax; windowSize++) {
    for (let start = 0; start <= haystack.length - windowSize; start++) {
      const candidate = haystack.substring(start, start + windowSize);
      const distance = levenshtein(needle, candidate);
      const similarity = 1 - distance / Math.max(n, windowSize);
      if (similarity > bestSimilarity) {
        bestSimilarity = similarity;
        bestStart = start;
        bestEnd = start + windowSize;
      }
    }
  }
  if (bestSimilarity >= 0.8) {
    return { start: bestStart, end: bestEnd, similarity: bestSimilarity };
  }
  return null;
}
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}
var GUTTER_VALUES = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65];
function stripGutterNumbers(concat) {
  const survive = new Uint8Array(concat.length).fill(1);
  for (const n of GUTTER_VALUES) {
    const numStr = String(n);
    const len = numStr.length;
    for (let pos = 0; pos <= concat.length - len; pos++) {
      if (concat.substring(pos, pos + len) === numStr) {
        const before = pos === 0 || concat[pos - 1] === " ";
        const after = pos + len === concat.length || concat[pos + len] === " ";
        if (before && after) {
          for (let k = pos; k < pos + len; k++) survive[k] = 0;
        }
      }
    }
  }
  const preCollapseToOrig = [];
  let preCollapse = "";
  for (let i = 0; i < concat.length; i++) {
    if (survive[i]) {
      preCollapseToOrig.push(i);
      preCollapse += concat[i];
    }
  }
  const strippedToOrig = [];
  let stripped = "";
  let prevWasSpace = false;
  for (let i = 0; i < preCollapse.length; i++) {
    const ch = preCollapse[i];
    if (ch === " ") {
      if (!prevWasSpace && stripped.length > 0) {
        strippedToOrig.push(preCollapseToOrig[i]);
        stripped += ch;
        prevWasSpace = true;
      }
    } else {
      strippedToOrig.push(preCollapseToOrig[i]);
      stripped += ch;
      prevWasSpace = false;
    }
  }
  if (stripped.endsWith(" ")) {
    stripped = stripped.slice(0, -1);
    strippedToOrig.pop();
  }
  const changed = stripped !== concat;
  return { stripped, strippedToOrig, changed };
}
function gutterTolerantMatch(selection, concat, boundaries, positionMap, contextBefore, contextAfter) {
  const { stripped, strippedToOrig, changed } = stripGutterNumbers(concat);
  if (!changed) return null;
  const origToStripped = new Int32Array(concat.length).fill(-1);
  for (let si = 0; si < strippedToOrig.length; si++) {
    origToStripped[strippedToOrig[si]] = si;
  }
  const remappedBoundaries = boundaries.map((b) => {
    let newStart = origToStripped[b.charStart];
    if (newStart === -1) {
      for (let j = b.charStart; j < concat.length; j++) {
        if (origToStripped[j] !== -1) {
          newStart = origToStripped[j];
          break;
        }
      }
    }
    if (newStart === -1) newStart = 0;
    let newEnd = -1;
    for (let j = b.charEnd - 1; j >= b.charStart; j--) {
      if (origToStripped[j] !== -1) {
        newEnd = origToStripped[j] + 1;
        break;
      }
    }
    if (newEnd === -1) newEnd = newStart + 1;
    return { charStart: newStart, charEnd: newEnd, entryIdx: b.entryIdx };
  });
  const exactPositions = findAllOccurrences(stripped, selection);
  if (exactPositions.length > 0) {
    const bestPos = pickBestByContext(exactPositions, selection.length, stripped, contextBefore, contextAfter);
    const result = resolveMatch(bestPos, bestPos + selection.length, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  const wsResult = whitespaceStrippedMatch(selection, stripped, remappedBoundaries, positionMap, contextBefore, contextAfter);
  if (wsResult) return { ...wsResult, confidence: 0.85 };
  if (selection.length > 60) {
    const beResult = bookendMatch(selection, stripped, remappedBoundaries, positionMap);
    if (beResult) return { ...beResult, confidence: 0.85 };
  }
  const fuzzyResult = fuzzySubstringMatch(selection, stripped);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    const result = resolveMatch(fuzzyResult.start, fuzzyResult.end, remappedBoundaries, positionMap, 0.85);
    if (result) return result;
  }
  return null;
}
function matchAndCite(selectedText, positionMap, contextBefore = "", contextAfter = "") {
  let normalized = normalizeText(selectedText);
  if (!normalized || normalized.length < 2) return null;
  if (!positionMap || positionMap.length === 0) return null;
  normalized = normalized.replace(/- ([a-z])/g, "$1");
  const { text: ocrNormalized, changed: selChanged } = normalizeOcr(normalized);
  const { concat, boundaries } = buildConcat(positionMap);
  function applyPenaltyIfNeeded(result) {
    if (!result || !selChanged) return result;
    return { ...result, confidence: result.confidence - 0.02 };
  }
  const allPositions = findAllOccurrences(concat, ocrNormalized);
  if (allPositions.length > 0) {
    const bestPos = pickBestByContext(allPositions, ocrNormalized.length, concat, contextBefore, contextAfter);
    const matchEnd = bestPos + ocrNormalized.length;
    return applyPenaltyIfNeeded(resolveMatch(bestPos, matchEnd, boundaries, positionMap, 1));
  }
  const strippedResult = whitespaceStrippedMatch(ocrNormalized, concat, boundaries, positionMap, contextBefore, contextAfter);
  if (strippedResult) return applyPenaltyIfNeeded(strippedResult);
  if (ocrNormalized.length > 60) {
    const bookendResult = bookendMatch(ocrNormalized, concat, boundaries, positionMap);
    if (bookendResult) return applyPenaltyIfNeeded(bookendResult);
  }
  const fuzzyResult = fuzzySubstringMatch(ocrNormalized, concat);
  if (fuzzyResult && fuzzyResult.similarity >= 0.8) {
    return applyPenaltyIfNeeded(resolveMatch(
      fuzzyResult.start,
      fuzzyResult.end,
      boundaries,
      positionMap,
      fuzzyResult.similarity
    ));
  }
  const gutterResult = gutterTolerantMatch(
    ocrNormalized,
    concat,
    boundaries,
    positionMap,
    contextBefore,
    contextAfter
  );
  if (gutterResult) return gutterResult;
  return null;
}
export {
  bookendMatch,
  buildConcat,
  findAllOccurrences,
  formatCitation,
  fuzzySubstringMatch,
  gutterTolerantMatch,
  levenshtein,
  matchAndCite,
  normalizeOcr,
  normalizeText,
  pickBestByContext,
  resolveMatch,
  stripGutterNumbers,
  whitespaceStrippedMatch
};
