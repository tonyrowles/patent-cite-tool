// src/shared/constants.js
var MSG = {
  PATENT_PAGE_DETECTED: "patent-page-detected",
  PDF_LINK_FOUND: "pdf-link-found",
  PDF_LINK_NOT_FOUND: "pdf-link-not-found",
  FETCH_PDF: "fetch-pdf",
  PDF_FETCH_RESULT: "pdf-fetch-result",
  PARSE_PDF: "parse-pdf",
  PARSE_RESULT: "parse-result",
  GET_STATUS: "get-status",
  LOOKUP_POSITION: "lookup-position",
  CITATION_RESULT: "citation-result",
  GENERATE_CITATION: "generate-citation",
  FETCH_USPTO_PDF: "fetch-uspto-pdf",
  USPTO_FETCH_RESULT: "uspto-fetch-result",
  CHECK_CACHE: "check-cache",
  CACHE_HIT_RESULT: "cache-hit-result",
  CACHE_MISS: "cache-miss",
  UPLOAD_TO_CACHE: "upload-to-cache",
  SUBMIT_REPORT: "submit-report"
  // PAY-05
};
var PATENT_TYPE = {
  GRANT: "grant",
  APPLICATION: "application"
};
var REPORT_CATEGORIES = Object.freeze([
  "inaccurate_citation",
  "no_match",
  "tool_not_working",
  "other"
]);

// src/shared/report-payload-builder.js
function buildReportPayload({ context, category, note, settings, errors, includeSelectionText }) {
  if (!context?.patentNumber || String(context.patentNumber).trim() === "") {
    throw new Error(
      "buildReportPayload: context.patentNumber is required and must not be empty"
    );
  }
  if (!REPORT_CATEGORIES.includes(category)) {
    throw new Error(
      `buildReportPayload: category "${category}" is not in REPORT_CATEGORIES (allowed: ${REPORT_CATEGORIES.join(", ")})`
    );
  }
  if (!context?.extensionVersion || String(context.extensionVersion).trim() === "") {
    throw new Error(
      "buildReportPayload: context.extensionVersion is required and must not be empty"
    );
  }
  const errorLog = errors != null ? [...errors] : [];
  const resolvedNote = note ?? null;
  const patentUrl = context.patentUrl ?? "https://patents.google.com/patent/US" + context.patentNumber;
  const payload = {
    category,
    patentNumber: context.patentNumber,
    patentUrl,
    ...includeSelectionText ? { selectionText: context.selectionText ?? null } : {},
    returnedCitation: context.returnedCitation ?? null,
    confidenceTier: context.confidenceTier ?? null,
    // string passthrough (D-04)
    extensionVersion: context.extensionVersion,
    browser: context.browser ?? null,
    os: context.os ?? null,
    xpathNode: context.xpathNode ?? null,
    scrollY: context.scrollY ?? null,
    viewportWidth: context.viewportWidth ?? null,
    viewportHeight: context.viewportHeight ?? null,
    pdfParseStatus: context.pdfParseStatus ?? null,
    triggerMode: settings?.triggerMode ?? null,
    errorLog,
    note: resolvedNote
  };
  return payload;
}

// src/content/citation-ui.js
var citationHost = null;
var citationShadow = null;
var _popupClickOutsideHandler = null;
var _popupDismissTimer = null;
function cancelPopupClickOutside() {
  if (_popupClickOutsideHandler) {
    document.removeEventListener("mousedown", _popupClickOutsideHandler);
    _popupClickOutsideHandler = null;
  }
  if (_popupDismissTimer !== null) {
    clearTimeout(_popupDismissTimer);
    _popupDismissTimer = null;
  }
}
function getCitationHost() {
  if (citationHost && document.body.contains(citationHost)) {
    while (citationShadow.firstChild) {
      citationShadow.removeChild(citationShadow.firstChild);
    }
    return { host: citationHost, shadow: citationShadow };
  }
  citationHost = document.createElement("div");
  citationHost.id = "patent-cite-host";
  citationHost.setAttribute("data-testid", "pct-citation-host");
  citationHost.style.cssText = "all: initial; position: fixed; z-index: 2147483647; pointer-events: none;";
  citationShadow = citationHost.attachShadow({ mode: "closed" });
  document.body.appendChild(citationHost);
  return { host: citationHost, shadow: citationShadow };
}
function dismissCitationUI() {
  if (citationHost && document.body.contains(citationHost)) {
    citationHost.remove();
    citationHost = null;
    citationShadow = null;
  }
}
function showSuccessToast(citation, rect) {
  const { host, shadow } = getCitationHost();
  const style = document.createElement("style");
  style.textContent = getSuccessToastCSS();
  shadow.appendChild(style);
  const pill = document.createElement("div");
  pill.className = "cite-toast-success";
  pill.textContent = citation;
  let top = rect.bottom + 6;
  let left = rect.left;
  if (top + 32 > window.innerHeight) {
    top = rect.top - 32 - 6;
  }
  if (left + 120 > window.innerWidth) {
    left = window.innerWidth - 120 - 4;
  }
  if (left < 4) left = 4;
  host.style.top = `${top}px`;
  host.style.left = `${left}px`;
  host.style.width = "auto";
  host.style.height = "auto";
  shadow.appendChild(pill);
  setTimeout(() => dismissCitationUI(), 2e3);
}
function showFailureToast(reason, rect) {
  const { host, shadow } = getCitationHost();
  const style = document.createElement("style");
  style.textContent = getFailureToastCSS();
  shadow.appendChild(style);
  const pill = document.createElement("div");
  pill.className = "cite-toast-failure";
  pill.textContent = reason;
  let top = rect.bottom + 6;
  let left = rect.left;
  if (top + 36 > window.innerHeight) {
    top = rect.top - 36 - 6;
  }
  if (left + 220 > window.innerWidth) {
    left = window.innerWidth - 220 - 4;
  }
  if (left < 4) left = 4;
  host.style.top = `${top}px`;
  host.style.left = `${left}px`;
  host.style.width = "auto";
  host.style.height = "auto";
  shadow.appendChild(pill);
  setTimeout(() => dismissCitationUI(), 4e3);
}
function getSuccessToastCSS() {
  return `
    .cite-toast-success {
      display: inline-block;
      background: #ecfdf5;
      border: 1px solid #a7f3d0;
      border-radius: 12px;
      padding: 4px 10px;
      font-family: 'SF Mono', 'Consolas', 'Monaco', monospace;
      font-size: 12px;
      font-weight: 600;
      color: #065f46;
      white-space: nowrap;
      box-shadow: 0 1px 4px rgba(0,0,0,0.10);
      pointer-events: none;
      opacity: 0;
      animation: cite-fade-in 0.15s ease forwards;
    }
    @keyframes cite-fade-in {
      to { opacity: 1; }
    }
  `;
}
function getFailureToastCSS() {
  return `
    .cite-toast-failure {
      display: inline-block;
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 8px;
      padding: 6px 12px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 12px;
      font-weight: 500;
      color: #991b1b;
      white-space: nowrap;
      box-shadow: 0 1px 4px rgba(0,0,0,0.10);
      pointer-events: none;
      opacity: 0;
      animation: cite-fade-in 0.15s ease forwards;
    }
    @keyframes cite-fade-in {
      to { opacity: 1; }
    }
  `;
}

// src/content/patent-info.js
function extractPatentInfo() {
  const pathname = window.location.pathname;
  const match = pathname.match(/\/patent\/(US[\dA-Z]+)/);
  if (!match) return null;
  const patentId = match[1];
  const kindMatch = patentId.match(/([A-Z]\d?)$/);
  const kindCode = kindMatch ? kindMatch[1] : null;
  const patentType = kindCode && ["A1", "A2", "A9"].includes(kindCode) ? PATENT_TYPE.APPLICATION : PATENT_TYPE.GRANT;
  return { patentId, patentType, kindCode };
}

// src/content/report-dialog.js
function getNodeXPath(node) {
  if (!node || node === document.body) return "/html/body";
  const parts = [];
  let current = node;
  while (current && current !== document.documentElement) {
    if (current.nodeType !== Node.ELEMENT_NODE) {
      current = current.parentNode;
      continue;
    }
    const tag = current.tagName.toLowerCase();
    let idx = 1;
    let sib = current.previousSibling;
    while (sib) {
      if (sib.nodeType === Node.ELEMENT_NODE && sib.tagName.toLowerCase() === tag) idx++;
      sib = sib.previousSibling;
    }
    parts.unshift(`${tag}[${idx}]`);
    current = current.parentNode;
  }
  return "/" + parts.join("/");
}
function getXPathFromSelection() {
  try {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    let node = sel.getRangeAt(0).startContainer;
    if (node.nodeType === Node.TEXT_NODE) node = node.parentNode;
    return getNodeXPath(node);
  } catch {
    return null;
  }
}
function getReportDiagnostics() {
  return {
    xpathNode: getXPathFromSelection(),
    scrollY: window.scrollY,
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight,
    selectionText: window.getSelection()?.toString() ?? null
  };
}
async function getPdfParseStatus(patentType) {
  if (patentType === "application") return "skipped";
  try {
    const data = await chrome.storage.local.get("currentPatent");
    const patent = data.currentPatent;
    if (!patent) return null;
    if (patent.status === "parsed" && patent.source === null) return "cache-hit";
    if (patent.status === "parsed") return "success";
    if (["error", "no-text-layer", "unavailable"].includes(patent.status)) return "failed";
    return null;
  } catch {
    return null;
  }
}
function getBrowserString() {
  const ua = navigator.userAgent;
  return ua.match(/Chrome\/[\d.]+/)?.[0] ?? ua.match(/Firefox\/[\d.]+/)?.[0] ?? null;
}
function getOsString() {
  const ua = navigator.userAgent;
  if (ua.includes("Windows NT 10.0")) return "Windows 10/11";
  if (ua.includes("Windows")) return "Windows";
  if (ua.includes("Mac OS X") || ua.includes("macOS")) return "macOS";
  if (ua.includes("Linux")) return "Linux";
  if (ua.includes("Android")) return "Android";
  if (ua.includes("iPhone") || ua.includes("iPad")) return "iOS";
  return null;
}
function getReportDialogCSS() {
  return `
    .cite-report-panel {
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.14);
      padding: 12px 14px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      color: #1a1a1a;
      min-width: 220px;
      max-width: 320px;
      width: auto;
      position: relative;
      pointer-events: auto;
    }
    .cite-report-radio-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-bottom: 10px;
    }
    .cite-report-radio-label {
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      font-size: 13px;
      color: #1a1a1a;
      line-height: 1.4;
    }
    .cite-report-radio-label input[type="radio"] {
      accent-color: #3b82f6;
      border: 1px solid #d1d5db;
      flex-shrink: 0;
      cursor: pointer;
    }
    .cite-report-radio-label.checked {
      font-weight: 500;
      color: #1a1a1a;
    }
    .cite-report-radio-label:hover {
      color: #1a1a1a;
    }
    .cite-report-note {
      width: 100%;
      box-sizing: border-box;
      border: 1px solid #d1d5db;
      border-radius: 4px;
      padding: 6px 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      color: #1a1a1a;
      resize: vertical;
      background: #f9fafb;
      line-height: 1.4;
    }
    .cite-report-note:focus {
      border-color: #3b82f6;
      outline: none;
      box-shadow: 0 0 0 2px rgba(59,130,246,0.2);
    }
    .cite-report-counter {
      text-align: right;
      font-size: 11px;
      color: #6b7280;
      margin-top: 2px;
      line-height: 1.4;
    }
    .cite-report-counter.at-limit {
      color: #dc2626;
    }
    .cite-report-disclosure {
      font-size: 11px;
      color: #6b7280;
      margin-bottom: 8px;
      margin-top: 8px;
      line-height: 1.4;
    }
    .cite-report-whats-included-toggle {
      background: none;
      border: none;
      color: #3b82f6;
      font-size: 11px;
      cursor: pointer;
      padding: 0;
      text-decoration: underline;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .cite-report-whats-included-toggle:focus {
      outline: 2px solid #3b82f6;
      outline-offset: 2px;
    }
    .cite-report-whats-included {
      overflow: hidden;
      border-top: 1px solid #f3f4f6;
      margin-top: 8px;
      padding-top: 8px;
      display: none;
    }
    .cite-report-whats-included.expanded {
      display: block;
    }
    .cite-report-field-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .cite-report-field-row {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
    }
    .cite-report-field-label {
      color: #6b7280;
      flex-shrink: 0;
      padding-right: 8px;
    }
    .cite-report-field-value {
      color: #1a1a1a;
      text-align: right;
      word-break: break-all;
    }
    .cite-report-selection-toggle-label {
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      margin-top: 6px;
      font-size: 11px;
      color: #374151;
      line-height: 1.4;
    }
    .cite-report-selection-toggle-label input[type="checkbox"] {
      accent-color: #3b82f6;
      cursor: pointer;
    }
    .cite-report-btn-row {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
      margin-top: 12px;
    }
    .cite-report-submit {
      background: #ecfdf5;
      border: 1px solid #a7f3d0;
      color: #065f46;
      border-radius: 4px;
      padding: 4px 12px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .cite-report-submit:hover {
      background: #d1fae5;
    }
    .cite-report-submit:focus {
      outline: 2px solid #059669;
      outline-offset: 2px;
    }
    .cite-report-submit:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    .cite-report-cancel {
      background: #f9fafb;
      border: 1px solid #d1d5db;
      color: #374151;
      border-radius: 4px;
      padding: 4px 12px;
      font-size: 13px;
      font-weight: 400;
      cursor: pointer;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .cite-report-cancel:hover {
      background: #f3f4f6;
    }
    .cite-report-cancel:focus {
      outline: 2px solid #3b82f6;
      outline-offset: 2px;
    }
  `;
}
function installFocusTrap(shadowRoot, panelEl, onEscape) {
  const FOCUSABLE = [
    "button:not([disabled])",
    "input:not([disabled])",
    "textarea:not([disabled])",
    '[tabindex]:not([tabindex="-1"])',
    "a[href]"
  ].join(", ");
  function getFocusable() {
    return Array.from(panelEl.querySelectorAll(FOCUSABLE));
  }
  function handleKeydown(e) {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      onEscape();
      return;
    }
    if (e.key !== "Tab") return;
    const focusable2 = getFocusable();
    if (focusable2.length === 0) {
      e.preventDefault();
      return;
    }
    const first = focusable2[0];
    const last = focusable2[focusable2.length - 1];
    const active = shadowRoot.activeElement;
    if (e.shiftKey) {
      if (active === first || !focusable2.includes(active)) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (active === last || !focusable2.includes(active)) {
        e.preventDefault();
        first.focus();
      }
    }
  }
  shadowRoot.addEventListener("keydown", handleKeydown);
  const focusable = getFocusable();
  if (focusable.length > 0) {
    setTimeout(() => focusable[0].focus(), 0);
  }
  return () => shadowRoot.removeEventListener("keydown", handleKeydown);
}
function installFocusTrapPage(panelEl, onEscape) {
  const FOCUSABLE = [
    "button:not([disabled])",
    "input:not([disabled])",
    "textarea:not([disabled])",
    '[tabindex]:not([tabindex="-1"])',
    "a[href]"
  ].join(", ");
  function getFocusable() {
    return Array.from(panelEl.querySelectorAll(FOCUSABLE));
  }
  function handleKeydown(e) {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      onEscape();
      return;
    }
    if (e.key !== "Tab") return;
    const focusable2 = getFocusable();
    if (focusable2.length === 0) {
      e.preventDefault();
      return;
    }
    const first = focusable2[0];
    const last = focusable2[focusable2.length - 1];
    const active = document.activeElement;
    if (e.shiftKey) {
      if (active === first || !focusable2.includes(active)) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (active === last || !focusable2.includes(active)) {
        e.preventDefault();
        first.focus();
      }
    }
  }
  document.addEventListener("keydown", handleKeydown);
  const focusable = getFocusable();
  if (focusable.length > 0) {
    setTimeout(() => focusable[0].focus(), 0);
  }
  return () => document.removeEventListener("keydown", handleKeydown);
}
var FIELD_LABELS = {
  patentNumber: "Patent number",
  selectionText: "The text you selected",
  patentUrl: "Page address",
  browserOs: "Browser & OS",
  extensionVersion: "Extension version",
  category: "Problem category",
  note: "Your note",
  errors: "Recent error log",
  scrollY: "Diagnostic: scroll position",
  viewport: "Diagnostic: viewport size",
  xpathNode: "Diagnostic: selected node",
  pdfParseStatus: "Diagnostic: PDF status"
};
var CATEGORY_LABELS = {
  inaccurate_citation: "Inaccurate citation",
  no_match: "No match found",
  tool_not_working: "Tool not working",
  other: "Other"
};
function showReportDialog(mountContext, reportOutcome, selectionRect, triggerEl, prebuiltContext = null) {
  cancelPopupClickOutside();
  const mountTarget = mountContext.mode === "shadow" ? mountContext.root : mountContext.container;
  const diagnostics = getReportDiagnostics();
  let includeSelectionText = true;
  const styleEl = document.createElement("style");
  styleEl.textContent = getReportDialogCSS();
  mountTarget.appendChild(styleEl);
  const panel = document.createElement("div");
  panel.className = "cite-report-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-modal", "true");
  panel.setAttribute("aria-label", "Report a citation problem");
  panel.style.pointerEvents = "auto";
  if (mountContext.mode === "page") {
    const staleBanner = document.createElement("div");
    staleBanner.className = "cite-report-stale-banner";
    staleBanner.style.cssText = "font-size:12px; color:#6b7280; margin-bottom:8px; padding:6px 8px; background:#f9fafb; border:1px solid #e5e7eb; border-radius:4px;";
    staleBanner.textContent = `Context from your most recent citation: US${prebuiltContext?.patentNumber || "(none)"}`;
    panel.appendChild(staleBanner);
  }
  const radioGroup = document.createElement("div");
  radioGroup.className = "cite-report-radio-group";
  const radioName = "cite-report-category-" + Date.now();
  const CATEGORIES = ["inaccurate_citation", "no_match", "tool_not_working", "other"];
  const radioEls = {};
  CATEGORIES.forEach((value) => {
    const labelEl = document.createElement("label");
    labelEl.className = "cite-report-radio-label";
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = radioName;
    radio.value = value;
    if (reportOutcome.category === value) {
      radio.checked = true;
      labelEl.classList.add("checked");
    }
    radio.addEventListener("change", () => {
      radioEls[value].labelEl.classList.toggle("checked", radio.checked);
      CATEGORIES.forEach((v) => {
        if (v !== value) {
          radioEls[v].labelEl.classList.remove("checked");
        }
      });
    });
    const labelText = document.createTextNode(CATEGORY_LABELS[value]);
    labelEl.appendChild(radio);
    labelEl.appendChild(labelText);
    radioGroup.appendChild(labelEl);
    radioEls[value] = { radio, labelEl };
  });
  panel.appendChild(radioGroup);
  const noteTextarea = document.createElement("textarea");
  noteTextarea.className = "cite-report-note";
  noteTextarea.maxLength = 256;
  noteTextarea.rows = 3;
  noteTextarea.placeholder = "Optional \u2014 add context for the maintainer";
  noteTextarea.setAttribute("aria-label", "Optional note, 256 character limit");
  panel.appendChild(noteTextarea);
  const counter = document.createElement("div");
  counter.className = "cite-report-counter";
  counter.setAttribute("aria-live", "polite");
  counter.textContent = "0 / 256";
  panel.appendChild(counter);
  noteTextarea.addEventListener("input", () => {
    const len = noteTextarea.value.length;
    counter.textContent = `${len} / 256`;
    if (len >= 256) {
      counter.classList.add("at-limit");
    } else {
      counter.classList.remove("at-limit");
    }
  });
  const disclosureEl = document.createElement("div");
  disclosureEl.className = "cite-report-disclosure";
  const disclosureText = document.createTextNode(
    "Includes patent #, your selection, URL, extension version \u2014 "
  );
  disclosureEl.appendChild(disclosureText);
  const whatsIncludedToggleBtn = document.createElement("button");
  whatsIncludedToggleBtn.className = "cite-report-whats-included-toggle";
  whatsIncludedToggleBtn.textContent = "see what\u2019s sent";
  whatsIncludedToggleBtn.setAttribute("aria-expanded", "false");
  disclosureEl.appendChild(whatsIncludedToggleBtn);
  panel.appendChild(disclosureEl);
  const whatsIncludedPanel = document.createElement("div");
  whatsIncludedPanel.className = "cite-report-whats-included";
  const fieldList = document.createElement("div");
  fieldList.className = "cite-report-field-list";
  function makeFieldRow(labelText, valueText, hidden) {
    const row = document.createElement("div");
    row.className = "cite-report-field-row";
    if (hidden) row.style.display = "none";
    const labelEl = document.createElement("span");
    labelEl.className = "cite-report-field-label";
    labelEl.textContent = labelText;
    const valueEl = document.createElement("span");
    valueEl.className = "cite-report-field-value";
    valueEl.textContent = valueText;
    row.appendChild(labelEl);
    row.appendChild(valueEl);
    return row;
  }
  const patentInfo = extractPatentInfo();
  const rawPatentNumber = mountContext.mode === "page" ? prebuiltContext?.patentNumber ?? "" : (patentInfo?.patentId ?? "").replace(/^US/, "");
  fieldList.appendChild(makeFieldRow(FIELD_LABELS.patentNumber, rawPatentNumber || "\u2014"));
  const selectionTextValue = (mountContext.mode === "page" ? prebuiltContext?.selectionText ?? null : diagnostics.selectionText) || "(none)";
  const selectionRow = makeFieldRow(
    FIELD_LABELS.selectionText,
    selectionTextValue.length > 60 ? selectionTextValue.substring(0, 60) + "\u2026" : selectionTextValue
  );
  fieldList.appendChild(selectionRow);
  const displayUrl = mountContext.mode === "page" ? prebuiltContext?.patentNumber ? `https://patents.google.com/patent/US${prebuiltContext.patentNumber}` : "(no prior patent)" : window.location.href;
  fieldList.appendChild(makeFieldRow(FIELD_LABELS.patentUrl, displayUrl));
  const browserVal = getBrowserString() || "\u2014";
  const osVal = getOsString() || "\u2014";
  fieldList.appendChild(makeFieldRow(FIELD_LABELS.browserOs, `${browserVal} / ${osVal}`));
  const extVersion = chrome.runtime.getManifest().version;
  fieldList.appendChild(makeFieldRow(FIELD_LABELS.extensionVersion, extVersion));
  const getSelectedCategory = () => {
    for (const v of CATEGORIES) {
      if (radioEls[v].radio.checked) return CATEGORY_LABELS[v];
    }
    return "\u2014";
  };
  const categoryRow = makeFieldRow(FIELD_LABELS.category, getSelectedCategory());
  const categoryValueEl = categoryRow.querySelector(".cite-report-field-value");
  CATEGORIES.forEach((v) => {
    radioEls[v].radio.addEventListener("change", () => {
      categoryValueEl.textContent = getSelectedCategory();
    });
  });
  fieldList.appendChild(categoryRow);
  const noteRow = makeFieldRow(FIELD_LABELS.note, "none");
  const noteValueEl = noteRow.querySelector(".cite-report-field-value");
  noteTextarea.addEventListener("input", () => {
    noteValueEl.textContent = noteTextarea.value.trim() || "none";
  });
  fieldList.appendChild(noteRow);
  fieldList.appendChild(
    makeFieldRow(FIELD_LABELS.scrollY, `${diagnostics.scrollY}px`)
  );
  fieldList.appendChild(
    makeFieldRow(
      FIELD_LABELS.viewport,
      `${diagnostics.viewportWidth} \xD7 ${diagnostics.viewportHeight}`
    )
  );
  if (diagnostics.xpathNode) {
    const xpath = diagnostics.xpathNode.length > 60 ? diagnostics.xpathNode.substring(0, 60) + "\u2026" : diagnostics.xpathNode;
    fieldList.appendChild(makeFieldRow(FIELD_LABELS.xpathNode, xpath));
  }
  const pdfStatusRow = makeFieldRow(FIELD_LABELS.pdfParseStatus, "\u2026");
  fieldList.appendChild(pdfStatusRow);
  if (mountContext.mode === "page") {
    const pdfValEl = pdfStatusRow.querySelector(".cite-report-field-value");
    if (pdfValEl) pdfValEl.textContent = prebuiltContext?.pdfParseStatus ?? null ?? "unknown";
  } else {
    const patentType = patentInfo?.patentType ?? null;
    getPdfParseStatus(patentType).then((status) => {
      const pdfValEl = pdfStatusRow.querySelector(".cite-report-field-value");
      if (pdfValEl) pdfValEl.textContent = status ?? "unknown";
    });
  }
  whatsIncludedPanel.appendChild(fieldList);
  const selectionToggleLabel = document.createElement("label");
  selectionToggleLabel.className = "cite-report-selection-toggle-label";
  const selectionToggle = document.createElement("input");
  selectionToggle.type = "checkbox";
  selectionToggle.className = "cite-report-selection-toggle";
  const selectionToggleText = document.createTextNode("Remove selection text");
  selectionToggleLabel.appendChild(selectionToggle);
  selectionToggleLabel.appendChild(selectionToggleText);
  whatsIncludedPanel.appendChild(selectionToggleLabel);
  const effectiveSelectionText = mountContext.mode === "shadow" ? diagnostics.selectionText : prebuiltContext?.selectionText ?? null;
  const hasSelection = !!effectiveSelectionText;
  if (!hasSelection) {
    selectionToggleLabel.style.display = "none";
    includeSelectionText = false;
  }
  chrome.storage.local.get("reportDialogRemoveSelectionText").then((stored) => {
    const saved = stored.reportDialogRemoveSelectionText === true;
    selectionToggle.checked = saved;
    if (hasSelection) {
      includeSelectionText = !saved;
      selectionRow.style.display = saved && hasSelection ? "none" : "";
    }
    submitBtn.disabled = false;
  }).catch(() => {
    submitBtn.disabled = false;
  });
  selectionToggle.addEventListener("change", () => {
    const remove = selectionToggle.checked;
    includeSelectionText = !remove;
    selectionRow.style.display = remove ? "none" : "";
    chrome.storage.local.set({ reportDialogRemoveSelectionText: remove }).catch(() => {
    });
  });
  panel.appendChild(whatsIncludedPanel);
  whatsIncludedToggleBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const expanded = whatsIncludedPanel.classList.toggle("expanded");
    whatsIncludedToggleBtn.setAttribute("aria-expanded", String(expanded));
  });
  const btnRow = document.createElement("div");
  btnRow.className = "cite-report-btn-row";
  const submitBtn = document.createElement("button");
  submitBtn.className = "cite-report-submit";
  submitBtn.textContent = "Submit report";
  submitBtn.disabled = true;
  const cancelBtn = document.createElement("button");
  cancelBtn.className = "cite-report-cancel";
  cancelBtn.textContent = "Cancel";
  btnRow.appendChild(submitBtn);
  btnRow.appendChild(cancelBtn);
  panel.appendChild(btnRow);
  mountTarget.appendChild(panel);
  if (selectionRect && mountContext.mode === "shadow") {
    const citationHost2 = mountContext.root.host;
    const panelWidth = 320;
    let top = selectionRect.bottom + 8;
    let left = selectionRect.left;
    if (top + 200 > window.innerHeight) {
      top = selectionRect.top - 200;
      if (top < 8) top = 8;
    }
    if (left + panelWidth > window.innerWidth) {
      left = window.innerWidth - panelWidth - 8;
    }
    if (left < 8) left = 8;
    citationHost2.style.top = `${top}px`;
    citationHost2.style.left = `${left}px`;
    citationHost2.style.width = "auto";
    citationHost2.style.height = "auto";
  }
  function dismissDialog() {
    removeTrap();
    document.removeEventListener("mousedown", clickOutsideHandler);
    panel.remove();
    styleEl.remove();
    if (mountContext.mode === "shadow" && triggerEl && typeof triggerEl.focus === "function") {
      triggerEl.focus();
    }
  }
  function clickOutsideHandler(e) {
    if (mountContext.mode === "shadow") {
      const citationHost2 = mountContext.root.host;
      if (!citationHost2 || !citationHost2.contains(e.target)) {
        dismissDialog();
      }
    } else {
      if (!mountContext.container.contains(e.target)) {
        dismissDialog();
      }
    }
  }
  setTimeout(() => {
    if (mountContext.mode === "shadow") {
      document.addEventListener("mousedown", clickOutsideHandler);
    }
  }, 100);
  cancelBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    dismissDialog();
  });
  const removeTrap = mountContext.mode === "shadow" ? installFocusTrap(mountContext.root, panel, () => dismissDialog()) : installFocusTrapPage(panel, () => dismissDialog());
  submitBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    let selectedCategory = null;
    for (const v of CATEGORIES) {
      if (radioEls[v].radio.checked) {
        selectedCategory = v;
        break;
      }
    }
    if (!selectedCategory) {
      const hint = panel.querySelector(".cite-report-category-hint") || (() => {
        const el = document.createElement("p");
        el.className = "cite-report-category-hint";
        el.style.cssText = "font-size:12px; color:#991b1b; margin:4px 0 0;";
        radioGroup.insertAdjacentElement("afterend", el);
        return el;
      })();
      hint.textContent = "Please select a problem category.";
      return;
    }
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting\u2026";
    try {
      let context;
      let errors;
      if (prebuiltContext) {
        const errorsStored = await chrome.storage.local.get("bugReportErrorBuffer");
        errors = Array.isArray(errorsStored.bugReportErrorBuffer) ? errorsStored.bugReportErrorBuffer : [];
        context = {
          patentNumber: prebuiltContext.patentNumber ?? "",
          selectionText: prebuiltContext.selectionText ?? null,
          returnedCitation: prebuiltContext.returnedCitation ?? null,
          confidenceTier: prebuiltContext.confidenceTier ?? null,
          extensionVersion: prebuiltContext.extensionVersion ?? chrome.runtime.getManifest().version,
          browser: getBrowserString(),
          os: getOsString(),
          xpathNode: null,
          scrollY: null,
          viewportWidth: null,
          viewportHeight: null,
          pdfParseStatus: prebuiltContext.pdfParseStatus ?? null
        };
      } else {
        const patentInfoNow = extractPatentInfo();
        const patentNumber = (patentInfoNow?.patentId ?? "").replace(/^US/, "");
        const patentTypeNow = patentInfoNow?.patentType ?? null;
        const pdfParseStatus = await getPdfParseStatus(patentTypeNow);
        const errorsStored = await chrome.storage.local.get("bugReportErrorBuffer");
        errors = Array.isArray(errorsStored.bugReportErrorBuffer) ? errorsStored.bugReportErrorBuffer : [];
        context = {
          patentNumber,
          selectionText: diagnostics.selectionText,
          returnedCitation: reportOutcome.returnedCitation ?? null,
          confidenceTier: reportOutcome.confidenceTier,
          extensionVersion: chrome.runtime.getManifest().version,
          browser: getBrowserString(),
          os: getOsString(),
          xpathNode: diagnostics.xpathNode,
          scrollY: diagnostics.scrollY,
          viewportWidth: diagnostics.viewportWidth,
          viewportHeight: diagnostics.viewportHeight,
          pdfParseStatus
        };
      }
      const settings = { triggerMode: null };
      const noteValue = noteTextarea.value.trim() || null;
      const payload = buildReportPayload({
        context,
        category: selectedCategory,
        note: noteValue,
        settings,
        errors,
        includeSelectionText
      });
      const result = await chrome.runtime.sendMessage({
        type: MSG.SUBMIT_REPORT,
        payload
      });
      if (mountContext.mode === "shadow") {
        dismissDialog();
        if (result?.ok) {
          showSuccessToast("Report sent \u2014 thank you", selectionRect);
        } else if (result?.queued) {
          showSuccessToast("Report saved \u2014 will retry when online", selectionRect);
        } else if (result?.rateLimited) {
          showFailureToast(
            "Too many reports in a short period \u2014 please wait a few minutes",
            selectionRect
          );
        }
      } else {
        if (result?.rateLimited) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Submit report";
          const existingRateError = panel.querySelector(".cite-report-rate-error");
          if (!existingRateError) {
            const rateErrEl = document.createElement("p");
            rateErrEl.className = "cite-report-rate-error";
            rateErrEl.style.cssText = "font-size:13px; color:#991b1b; margin:8px 0 0;";
            rateErrEl.textContent = "Too many reports in a short period \u2014 please wait a few minutes.";
            btnRow.insertAdjacentElement("beforebegin", rateErrEl);
          }
        } else {
          dismissDialog();
          const confirmEl = document.createElement("p");
          if (result?.ok) {
            confirmEl.style.cssText = "font-size:13px; color:#059669; padding:12px 0;";
            confirmEl.textContent = "Report sent \u2014 thank you.";
          } else if (result?.queued) {
            confirmEl.style.cssText = "font-size:13px; color:#64748b; padding:12px 0;";
            confirmEl.textContent = "Report saved \u2014 will retry when online.";
          }
          if (result?.ok || result?.queued) {
            mountContext.container.appendChild(confirmEl);
          }
        }
      }
    } catch (err) {
      console.error("[PCT] report submit failed:", err?.message || err);
      if (mountContext.mode === "shadow") {
        dismissDialog();
        showFailureToast(
          "Report could not be sent \u2014 please try again",
          selectionRect
        );
      } else {
        submitBtn.disabled = false;
        submitBtn.textContent = "Submit report";
        const existingErr = panel.querySelector(".cite-report-rate-error");
        if (!existingErr) {
          const errEl = document.createElement("p");
          errEl.className = "cite-report-rate-error";
          errEl.style.cssText = "font-size:13px; color:#991b1b; margin:8px 0 0;";
          errEl.textContent = "Report could not be sent \u2014 please try again.";
          btnRow.insertAdjacentElement("beforebegin", errEl);
        }
      }
    }
  });
}

// src/options/prebuilt-context.js
function buildPrebuiltContext(patent, lastCitationOutcome, version) {
  if (!patent || !patent.patentId) return null;
  const matched = lastCitationOutcome && lastCitationOutcome.patentId === patent.patentId ? lastCitationOutcome : null;
  return {
    patentNumber: patent.patentId.replace(/^US/, ""),
    selectionText: null,
    // D-01: no live selection on options page
    returnedCitation: matched?.returnedCitation ?? null,
    confidenceTier: matched?.confidenceTier ?? null,
    extensionVersion: version,
    xpathNode: null,
    scrollY: null,
    viewportWidth: null,
    viewportHeight: null,
    pdfParseStatus: null
  };
}

// src/options/options.js
document.addEventListener("DOMContentLoaded", () => {
  const versionEl = document.getElementById("version");
  if (versionEl) {
    versionEl.textContent = "v" + chrome.runtime.getManifest().version;
  }
  const triggerSelect = document.getElementById("triggerMode");
  const displaySelect = document.getElementById("displayMode");
  const patentNumCheckbox = document.getElementById("includePatentNumber");
  const debugModeCheckbox = document.getElementById("debugMode");
  const triggerSaved = document.getElementById("triggerSaved");
  const displaySaved = document.getElementById("displaySaved");
  const patentNumSaved = document.getElementById("patentNumSaved");
  const debugModeSaved = document.getElementById("debugModeSaved");
  const silentHelp = document.getElementById("silentHelp");
  function showSaved(el) {
    if (!el) return;
    el.style.opacity = "1";
    setTimeout(() => {
      el.style.opacity = "0";
    }, 1500);
  }
  function updateSilentHelp(value) {
    if (silentHelp) {
      silentHelp.style.display = value === "silent" ? "block" : "none";
    }
  }
  chrome.storage.sync.get({
    triggerMode: "floating-button",
    displayMode: "default",
    includePatentNumber: false,
    debugMode: false
  }, (settings) => {
    triggerSelect.value = settings.triggerMode;
    displaySelect.value = settings.displayMode;
    if (patentNumCheckbox) {
      patentNumCheckbox.checked = settings.includePatentNumber;
    }
    if (debugModeCheckbox) {
      debugModeCheckbox.checked = settings.debugMode;
    }
    updateSilentHelp(settings.triggerMode);
  });
  triggerSelect.addEventListener("change", () => {
    chrome.storage.sync.set({ triggerMode: triggerSelect.value }, () => {
      showSaved(triggerSaved);
    });
    updateSilentHelp(triggerSelect.value);
  });
  displaySelect.addEventListener("change", () => {
    chrome.storage.sync.set({ displayMode: displaySelect.value }, () => {
      showSaved(displaySaved);
    });
  });
  if (patentNumCheckbox) {
    patentNumCheckbox.addEventListener("change", () => {
      chrome.storage.sync.set({ includePatentNumber: patentNumCheckbox.checked }, () => {
        showSaved(patentNumSaved);
      });
    });
  }
  if (debugModeCheckbox) {
    debugModeCheckbox.addEventListener("change", () => {
      chrome.storage.sync.set({ debugMode: debugModeCheckbox.checked }, () => {
        showSaved(debugModeSaved);
      });
    });
  }
  chrome.storage.local.get("pendingOptionsHash", (data) => {
    if (data.pendingOptionsHash === "#report") {
      chrome.storage.local.remove("pendingOptionsHash", () => {
      });
      const reportSection = document.getElementById("report");
      if (reportSection) reportSection.scrollIntoView({ behavior: "smooth" });
    }
  });
  if (location.hash === "#report") {
    const reportSection = document.getElementById("report");
    if (reportSection) reportSection.scrollIntoView({ behavior: "smooth" });
  }
  const reportMount = document.getElementById("reportDialogMount");
  let dialogMounted = false;
  function initPageModeDialog() {
    if (dialogMounted) return;
    if (!reportMount) return;
    chrome.storage.local.get(["currentPatent", "lastCitationOutcome"], (data) => {
      if (dialogMounted) return;
      dialogMounted = true;
      const patent = data.currentPatent;
      if (!patent || !patent.patentId) {
        const placeholder = document.createElement("p");
        placeholder.style.cssText = "font-size:13px; color:#6b7280; padding:8px 0;";
        placeholder.textContent = "Visit a US patent on Google Patents and run a citation first \u2014 then return here to report a problem.";
        reportMount.appendChild(placeholder);
        return;
      }
      const prebuiltContext = buildPrebuiltContext(
        patent,
        data.lastCitationOutcome,
        chrome.runtime.getManifest().version
      );
      showReportDialog(
        { mode: "page", container: reportMount },
        { category: null, confidenceTier: null },
        // D-02: no category pre-selected
        null,
        // no selectionRect — page mode, document flow
        null,
        // no triggerEl
        prebuiltContext
      );
    });
  }
  initPageModeDialog();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.pendingOptionsHash?.newValue === "#report") {
      chrome.storage.local.remove("pendingOptionsHash", () => {
      });
      const reportSection = document.getElementById("report");
      if (reportSection) reportSection.scrollIntoView({ behavior: "smooth" });
      initPageModeDialog();
    }
  });
});
